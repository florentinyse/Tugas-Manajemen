// Memindai public/audio/narasi dan menulis public/audio-manifest.json.
// Nama file: scene-01.mp3 ... scene-09.mp3 (juga .wav/.m4a/.ogg) -> sesuai id adegan s01..s09.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dir = path.join(root, 'public', 'audio', 'narasi');
const timing = JSON.parse(fs.readFileSync(path.join(root, 'public', 'timing.json'), 'utf8'));
const exts = ['.mp3', '.wav', '.m4a', '.ogg', '.aac'];
fs.mkdirSync(dir, {recursive: true});
const files = fs.readdirSync(dir);
const narration = {};
const missing = [];
for (const sc of timing.scenes) {
  const n = String(sc.number).padStart(2, '0');
  const hit = files.find((f) => exts.includes(path.extname(f).toLowerCase()) && path.basename(f, path.extname(f)).toLowerCase() === `scene-${n}`);
  if (hit) narration[sc.id] = `audio/narasi/${hit}`;
  else missing.push(`scene-${n}`);
}
fs.writeFileSync(path.join(root, 'public', 'audio-manifest.json'), JSON.stringify({narration}, null, 2));
const found = Object.keys(narration).length;
console.log(`[prepare] audio narasi ditemukan: ${found}/${timing.scenes.length}`);
if (missing.length) {
  console.log(`[prepare] belum ada: ${missing.join(', ')} -> video tetap bisa dirender (tanpa suara narasi untuk adegan tsb).`);
}
