// Validasi public/timing.json: tanpa celah/tumpang tindih, kalimat berada di dalam adegan, durasi 3-5 menit.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const t = JSON.parse(fs.readFileSync(path.join(root, 'public', 'timing.json'), 'utf8'));
const errors = [];
const warns = [];
const err = (m) => errors.push(m);

if (t.fps !== 30) err(`fps harus 30 (saat ini ${t.fps})`);
if (t.width !== 1920 || t.height !== 1080) err('resolusi harus 1920x1080');
let cursor = 0;
for (const s of t.scenes) {
  if (s.startFrame !== cursor) err(`${s.id}: startFrame ${s.startFrame} != akhir adegan sebelumnya ${cursor} (celah/tumpang tindih)`);
  if (s.endFrame - s.startFrame !== s.durationFrames) err(`${s.id}: durationFrames tidak sama dengan endFrame-startFrame`);
  if (s.durationFrames <= 0) err(`${s.id}: durasi <= 0`);
  let prevEnd = s.startFrame;
  for (const l of s.lines) {
    if (l.startFrame < s.startFrame || l.endFrame > s.endFrame) err(`${l.id}: kalimat di luar batas adegan ${s.id}`);
    if (l.endFrame <= l.startFrame) err(`${l.id}: durasi kalimat <= 0`);
    if (l.startFrame < prevEnd) err(`${l.id}: tumpang tindih dengan kalimat sebelumnya`);
    prevEnd = l.endFrame;
  }
  let sp = s.startFrame;
  for (const b of s.subtitles) {
    if (b.startFrame < s.startFrame || b.endFrame > s.endFrame) err(`${b.id}: subtitle di luar batas adegan`);
    if (b.endFrame <= b.startFrame) err(`${b.id}: durasi subtitle <= 0`);
    if (b.startFrame < sp) err(`${b.id}: subtitle tumpang tindih`);
    if (b.text.length > 110) warns.push(`${b.id}: subtitle ${b.text.length} karakter (risiko >2 baris)`);
    sp = b.endFrame;
  }
  cursor = s.endFrame;
}
if (t.totalFrames !== cursor) err(`totalFrames ${t.totalFrames} != akhir adegan terakhir ${cursor}`);
const sec = t.totalFrames / t.fps;
if (sec < 180 || sec > 300) err(`durasi ${sec.toFixed(1)} detik di luar 3-5 menit`);
warns.forEach((w) => console.warn('[timing] PERINGATAN', w));
if (errors.length) {
  errors.forEach((e) => console.error('[timing] ERROR', e));
  process.exit(1);
}
console.log(`[timing] OK — ${t.scenes.length} adegan, ${t.totalFrames} frame, ${Math.floor(sec / 60)}m${Math.round(sec % 60)}s`);
