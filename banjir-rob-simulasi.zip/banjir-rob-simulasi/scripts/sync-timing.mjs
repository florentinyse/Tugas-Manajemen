// Menyesuaikan timing.json dengan durasi audio narasi yang sudah direkam.
// Pemakaian: letakkan scene-01.mp3 ... di public/audio/narasi lalu jalankan `npm run sync`.
// Durasi diukur dengan `remotion ffprobe` (ikut terpasang bersama @remotion/cli).
import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const timingPath = path.join(root, 'public', 'timing.json');
const t = JSON.parse(fs.readFileSync(timingPath, 'utf8'));
const dir = path.join(root, 'public', 'audio', 'narasi');
const exts = ['.mp3', '.wav', '.m4a', '.ogg', '.aac'];
const files = fs.existsSync(dir) ? fs.readdirSync(dir) : [];

const probe = (file) => {
  const args = ['remotion', 'ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', file];
  const out = execFileSync(process.platform === 'win32' ? 'npx.cmd' : 'npx', args, {cwd: root, encoding: 'utf8', shell: process.platform === 'win32'});
  const sec = parseFloat(out.trim().split(/\s+/).pop());
  if (!Number.isFinite(sec)) throw new Error(`gagal membaca durasi: ${file}`);
  return sec;
};

let cursor = 0;
const scenes = [];
for (const s of t.scenes) {
  const n = String(s.number).padStart(2, '0');
  const hit = files.find((f) => exts.includes(path.extname(f).toLowerCase()) && path.basename(f, path.extname(f)).toLowerCase() === `scene-${n}`);
  const first = s.lines[0].startFrame;
  const last = s.lines[s.lines.length - 1].endFrame;
  const lead = first - s.startFrame;
  const tail = s.endFrame - last;
  let k = 1;
  if (hit) {
    const audioFrames = Math.round(probe(path.join(dir, hit)) * t.fps);
    k = audioFrames / (last - first);
    console.log(`[sync] ${s.id}: audio ${(audioFrames / t.fps).toFixed(1)}s (estimasi ${((last - first) / t.fps).toFixed(1)}s)`);
  }
  const start = cursor;
  const map = (fr) => Math.round(start + lead + (fr - first) * k);
  const newFirst = start + lead;
  const lines = s.lines.map((l) => ({...l, startFrame: map(l.startFrame), endFrame: map(l.endFrame)}));
  const subtitles = s.subtitles.map((b) => ({...b, startFrame: map(b.startFrame), endFrame: map(b.endFrame)}));
  const end = lines[lines.length - 1].endFrame + tail;
  void newFirst;
  scenes.push({...s, startFrame: start, endFrame: end, durationFrames: end - start, lines, subtitles});
  cursor = end;
}
t.scenes = scenes;
t.totalFrames = cursor;
fs.writeFileSync(timingPath, JSON.stringify(t, null, 2));
console.log(`[sync] timing.json diperbarui: ${(cursor / t.fps).toFixed(1)} detik. Jalankan "npm run srt" untuk memperbarui narasi.srt.`);
