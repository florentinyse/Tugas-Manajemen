// Membuat narasi.srt dari public/timing.json (subtitle maks. 2 baris).
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const t = JSON.parse(fs.readFileSync(path.join(root, 'public', 'timing.json'), 'utf8'));
const ts = (frame) => {
  const ms = Math.round((frame / t.fps) * 1000);
  const h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000), s = Math.floor((ms % 60000) / 1000), r = ms % 1000;
  const p = (n, w = 2) => String(n).padStart(w, '0');
  return `${p(h)}:${p(m)}:${p(s)},${p(r, 3)}`;
};
const wrap = (text, max = 46) => {
  if (text.length <= max) return text;
  const mid = Math.floor(text.length / 2);
  let cut = text.lastIndexOf(' ', mid + 8);
  const alt = text.indexOf(' ', mid - 8);
  if (cut < mid - 14 && alt !== -1) cut = alt;
  if (cut === -1) return text;
  return `${text.slice(0, cut)}\n${text.slice(cut + 1)}`;
};
let i = 1;
const out = [];
for (const s of t.scenes) {
  for (const b of s.subtitles) {
    const label = b.speaker === 'Narator' ? '' : `${b.speaker}: `;
    out.push(`${i++}\n${ts(b.startFrame)} --> ${ts(b.endFrame)}\n${wrap(label + b.text)}\n`);
  }
}
fs.writeFileSync(path.join(root, 'narasi.srt'), out.join('\n'), 'utf8');
console.log(`[srt] narasi.srt ditulis (${i - 1} subtitle)`);
