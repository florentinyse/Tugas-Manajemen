// OPSIONAL: draf suara narasi gratis memakai eSpeak NG (harus terpasang di komputer; suara robotik).
// Menghasilkan public/audio/narasi/scene-XX.wav per adegan. Direkomendasikan memakai rekaman kelompok sendiri.
import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const t = JSON.parse(fs.readFileSync(path.join(root, 'public', 'timing.json'), 'utf8'));
const dir = path.join(root, 'public', 'audio', 'narasi');
fs.mkdirSync(dir, {recursive: true});
for (const s of t.scenes) {
  const n = String(s.number).padStart(2, '0');
  const out = path.join(dir, `scene-${n}.wav`);
  try {
    execFileSync('espeak-ng', ['-v', 'id', '-s', '150', '-w', out, s.narration], {stdio: 'inherit'});
    console.log(`[tts] ${out}`);
  } catch (e) {
    console.error('[tts] espeak-ng tidak ditemukan. Pasang eSpeak NG atau rekam narasi sendiri (lihat README).');
    process.exit(1);
  }
}
console.log('[tts] selesai. Jalankan "npm run sync" lalu "npm run srt".');
