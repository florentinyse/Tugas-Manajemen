#!/usr/bin/env python3
"""Membuat public/timing.json dan naskah.txt dari naskah di bawah ini.

Timing awal adalah ESTIMASI (kecepatan bicara ~3 kata/detik). Setelah audio narasi
direkam, jalankan `npm run sync` agar durasi mengikuti audio, atau edit
public/timing.json secara manual. Subtitle SRT dibuat dengan `npm run srt`.
"""
import json, math, re, os

FPS = 30
WPS = 3.0          # kata per detik (estimasi)
LINE_PAD = 0.25    # jeda tambahan setelah tiap kalimat (detik)
GAP = 0.25         # jeda antar kalimat (detik)
TAIL_END = 1.0     # tambahan 1 detik pada akhir video
SUB_MAX = 92       # maksimum karakter per potongan subtitle (2 baris)

TITLE = ("SIMULASI RESPONS KESEHATAN MASYARAKAT DALAM 72 JAM PERTAMA "
         "BANJIR ROB DAN RISIKO PENYAKIT BERBASIS LINGKUNGAN")

N = "Narator"
SCENES = [
 dict(id="s01", key="pembuka", title="Pembuka dan Situasi Bencana", h0=0, h1=0, lead=3.8, tail=0.5,
  visual="Permukiman rumah panggung di tepi sungai dan rawa terendam banjir rob; warga menyelamatkan barang; ±900 warga terdampak, ±200 di balai warga; tim 4 orang diperkenalkan.",
  lines=[
   (N, "Air pasang tinggi bertemu hujan deras, dan permukiman di tepi sungai dan rawa pun dilanda banjir rob."),
   (N, "Air menggenangi rumah warga lebih dari 24 jam. Sebagian memilih bertahan demi menjaga barang berharga."),
   (N, "Sekitar 900 penduduk terdampak, termasuk 120 anak-anak, 65 lansia, dan 18 ibu hamil."),
   (N, "Beberapa keluarga mengungsi ke rumah kerabat, dan sekitar 200 orang berkumpul di balai warga."),
   ("Nayla", "Saya Nayla, koordinator respons. Kita punya 72 jam pertama, dan kita mulai dari penilaian situasi."),
   ("Natasha", "Saya Natasha. Saya pegang surveilans dan pendataan."),
   ("Syifa", "Saya Syifa. Saya menangani air, sanitasi, dan kondisi lingkungan."),
   ("Kayla", "Saya Kayla. Saya mengurus logistik, komunikasi risiko, dan pemantauan warga."),
  ]),
 dict(id="s02", key="identifikasi", title="Identifikasi Masalah Prioritas", h0=0, h1=0, lead=0.5, tail=0.5,
  visual="Peta situasi sederhana dengan penandaan titik masalah dan daftar 8 masalah prioritas; koordinasi awal 4 anggota tim.",
  lines=[
   ("Nayla", "Sebelum bergerak, kita tentukan masalah prioritas. Syifa, bagaimana kondisi air?"),
   ("Syifa", "Septic tank dan saluran pembuangan terendam. Air sumur berubah warna dan berbau, jadi tidak aman diminum."),
   ("Natasha", "Sudah ada laporan diare dan keluhan kulit. Genangan juga berpotensi menjadi tempat berkembangnya nyamuk."),
   ("Kayla", "Air minum kemasan hanya cukup sekitar satu hari, dan kader belum menjangkau semua wilayah terdampak."),
   ("Nayla", "Anak-anak, lansia, dan ibu hamil kita dahulukan. Mari tandai semua titik masalah di peta."),
  ]),
 dict(id="s03", key="respons24", title="Respons 0–24 Jam", h0=0, h1=24, lead=0.5, tail=0.5,
  visual="Briefing di posko balai warga: koordinasi lintas pihak, RNA, surveilans awal, pemetaan wilayah belum terjangkau, pengamanan air, prioritas logistik, pembagian tugas.",
  lines=[
   ("Nayla", "Fase 0 sampai 24 jam. Saya koordinasikan pemerintah desa, Puskesmas, kader, relawan, dan pihak terkait dalam satu alur."),
   ("Natasha", "Kami lakukan Rapid Needs Assessment, atau penilaian cepat, untuk mendata lokasi terdampak, pengungsian, kelompok rentan, dan kebutuhan dasar."),
   ("Natasha", "Surveilans awal mencatat keluhan diare dan penyakit kulit. Wilayah yang belum terjangkau kami tandai di peta."),
   ("Syifa", "Sumur yang tercemar kami beri tanda dilarang diminum, dan warga diedukasi memakai air minum aman."),
   ("Kayla", "Air minum dan logistik kami salurkan lebih dulu ke balai warga. Ibu hamil, anak, dan lansia jadi prioritas."),
   ("Nayla", "Tugas sudah jelas. Semua laporan masuk lewat satu jalur koordinasi."),
  ]),
 dict(id="s04", key="respons48", title="Respons 24–48 Jam", h0=24, h1=36, lead=0.5, tail=0.5,
  visual="Lapangan dan balai warga: pencatatan kasus, edukasi cuci tangan pakai sabun, sanitasi darurat, pengelolaan genangan yang aman, distribusi logistik, kader memantau warga di rumah.",
  lines=[
   (N, "Memasuki 24 sampai 48 jam, respons difokuskan pada pemantauan dan pencegahan."),
   ("Natasha", "Kasus diare, keluhan kulit, dan gejala lain kami catat setiap hari di balai warga."),
   ("Syifa", "Saya ajarkan cuci tangan pakai sabun, pengolahan air aman, serta sanitasi darurat dan pengelolaan limbah."),
   ("Syifa", "Genangan yang aman dijangkau kami kelola, tanpa membahayakan warga."),
   ("Kayla", "Saya sampaikan komunikasi risiko kepada warga, dan membagikan kebutuhan kesehatan serta logistik."),
   ("Kayla", "Kader memantau warga yang masih bertahan di rumah, terutama lansia dan ibu hamil."),
   ("Warga", "Apakah air sumur boleh dipakai untuk memasak?"),
   ("Syifa", "Sebaiknya jangan, Bu. Pakai air minum aman yang kami bagikan."),
   ("Nayla", "Semua temuan masuk satu laporan, dan kita evaluasi setiap hari."),
  ]),
 dict(id="s05", key="perkembangan", title="Perkembangan Situasi dan Penyesuaian Respons", h0=36, h1=48, lead=0.5, tail=0.5,
  visual="Hari kedua: genangan belum berkurang, kader melaporkan warga demam; tim menilai ulang, memperkuat surveilans, merujuk ke Puskesmas, menyesuaikan logistik dan pemantauan.",
  lines=[
   (N, "Hari kedua. Genangan belum berkurang berarti, dan beberapa warga mulai demam."),
   ("Kader", "Ada beberapa warga demam di wilayah yang belum terjangkau."),
   ("Nayla", "Demam adalah gejala yang perlu dinilai lebih lanjut. Kita belum menyimpulkan penyebabnya, jadi kita nilai ulang situasinya."),
   ("Natasha", "Surveilans demam dan keluhan lain saya perkuat. Warga yang perlu pemeriksaan kami data untuk dirujuk ke Puskesmas."),
   ("Kayla", "Prioritas logistik kami sesuaikan, dan kader memperkuat pemantauan di wilayah yang belum terjangkau."),
   ("Syifa", "Risiko lingkungan dan genangan saya tinjau ulang bersama tim."),
  ]),
 dict(id="s06", key="respons72", title="Respons 48–72 Jam", h0=48, h1=72, lead=0.5, tail=0.5,
  visual="Penguatan respons hingga jam ke-72: pemantauan berkala, surveilans dan pelaporan, evaluasi air minum aman, sanitasi darurat, pengendalian vektor, logistik, tindak lanjut.",
  lines=[
   (N, "Menuju jam ke-72, respons diperkuat dan dievaluasi."),
   ("Natasha", "Pemantauan kesehatan dilakukan berkala, dan pelaporan surveilans kami perkuat."),
   ("Syifa", "Distribusi air minum aman dievaluasi, sanitasi darurat diperkuat, dan pengendalian vektor disesuaikan dengan kondisi lapangan."),
   ("Kayla", "Kebutuhan logistik dihitung ulang, dan kelompok rentan tetap kami pantau."),
   ("Nayla", "Koordinasi lintas sektor berlanjut. Kita tentukan tindak lanjut setelah fase respons awal."),
  ]),
 dict(id="s07", key="indikator", title="Indikator Pemantauan", h0=72, h1=72, lead=0.5, tail=0.5,
  visual="Tiga kartu indikator: definisi, cara pengukuran, dan target simulasi (bukan hasil nyata).",
  lines=[
   (N, "Tiga indikator memantau jalannya respons. Angkanya adalah target simulasi, bukan hasil nyata."),
   ("Natasha", "Pertama, surveilans kesehatan: persentase warga terdampak atau pengungsi yang terdata dan dipantau dalam 72 jam."),
   ("Syifa", "Kedua, air minum aman: persentase lokasi pengungsian atau rumah tangga prioritas yang memperoleh akses sesuai kebutuhan."),
   ("Kayla", "Ketiga, respons penyakit: persentase laporan diare, keluhan kulit, atau demam yang ditindaklanjuti atau dirujuk sesuai indikasi."),
  ]),
 dict(id="s08", key="risiko", title="Risiko Pelaksanaan dan Mitigasi", h0=72, h1=72, lead=0.5, tail=0.5,
  visual="Dua kartu risiko beserta mitigasinya: akses sulit dijangkau; air minum aman dan logistik terbatas.",
  lines=[
   (N, "Ada dua risiko pelaksanaan yang perlu diantisipasi."),
   ("Nayla", "Risiko pertama, wilayah sulit dijangkau karena genangan. Mitigasinya: kader lokal, pemetaan wilayah, prioritas akses, dan distribusi bertahap bersama relawan."),
   ("Kayla", "Risiko kedua, air minum aman dan logistik terbatas. Kami tentukan prioritas, cari sumber tambahan, dan pantau stok berkala."),
  ]),
 dict(id="s09", key="penutup", title="Penutup", h0=72, h1=72, lead=0.5, tail=0.5,
  visual="Tim, kader, dan warga bekerja sama di depan balai warga; ringkasan enam kebutuhan respons dan pesan penutup.",
  lines=[
   ("Nayla", "Respons banjir rob membutuhkan koordinasi lintas sektor, penilaian cepat, air, sanitasi, dan higiene, serta perlindungan kelompok rentan."),
   ("Natasha", "Juga pengendalian risiko penyakit berbasis lingkungan, serta pemantauan dan penyesuaian respons mengikuti perkembangan situasi."),
   (N, "Di lahan basah, kesehatan dijaga bersama warga."),
  ]),
]

def fr(sec): return int(round(sec * FPS))

def chunk(text, maxlen):
    parts = re.split(r'(?<=[.!?])\s+', text.strip())
    out = []
    for p in parts:
        if len(p) <= maxlen:
            out.append(p); continue
        pieces = re.split(r'(?<=,)\s+', p)
        cur = ''
        for pc in pieces:
            if cur and len(cur) + 1 + len(pc) > maxlen:
                out.append(cur); cur = pc
            else:
                cur = (cur + ' ' + pc).strip()
        if cur: out.append(cur)
    merged = []
    for c in out:
        if merged and len(merged[-1]) + 1 + len(c) <= maxlen:
            merged[-1] += ' ' + c
        else:
            merged.append(c)
    final = []
    for c in merged:
        while len(c) > maxlen + 6:
            cut = c.rfind(' ', 0, len(c) // 2 + 8)
            if cut < 10:
                break
            final.append(c[:cut]); c = c[cut + 1:]
        final.append(c)
    return final

def build():
    cursor = 0
    scenes = []
    for n, s in enumerate(SCENES, 1):
        start = cursor
        t = start + fr(s["lead"])
        lines, subs = [], []
        for i, (spk, text) in enumerate(s["lines"]):
            words = len(text.split())
            d = fr(words / WPS + LINE_PAD)
            lines.append(dict(id=f'{s["id"]}-l{i+1:02d}', speaker=spk, startFrame=t, endFrame=t + d, text=text))
            prefix = 0 if spk == N else len(spk) + 2
            chunks = chunk(text, SUB_MAX - prefix)
            total = sum(len(c) for c in chunks)
            ct = t
            for j, c in enumerate(chunks):
                cd = d * len(c) / total
                ce = t + d if j == len(chunks) - 1 else int(round(ct + cd))
                subs.append(dict(id=f'{s["id"]}-s{len(subs)+1:02d}', speaker=spk, startFrame=int(round(ct)), endFrame=ce, text=c))
                ct = ce
            t += d + fr(GAP)
        end = lines[-1]["endFrame"] + fr(s["tail"])
        if n == len(SCENES):
            end += fr(TAIL_END)
        scenes.append(dict(id=s["id"], number=n, title=s["title"], sceneKey=s["key"],
            startFrame=start, endFrame=end, durationFrames=end - start,
            hourStart=s["h0"], hourEnd=s["h1"],
            narration=" ".join(x[1] for x in s["lines"]), lines=lines, subtitles=subs))
        cursor = end
    return scenes

if __name__ == "__main__":
    scenes = build()
    total = scenes[-1]["endFrame"]
    timing = dict(fps=FPS, width=1920, height=1080, title=TITLE, totalFrames=total,
                  tailFrames=fr(TAIL_END), scenes=scenes)
    root = os.path.join(os.path.dirname(__file__), "..")
    with open(os.path.join(root, "public", "timing.json"), "w", encoding="utf-8") as f:
        json.dump(timing, f, ensure_ascii=False, indent=2)
    # naskah.txt
    out = [TITLE, "Skenario 5 — Banjir Rob dan Penyakit Berbasis Lingkungan",
           "Mata kuliah: Manajemen Bencana di Lingkungan Lahan Basah dan KLB", "",
           f"Durasi estimasi: {total/FPS:.0f} detik ({int(total//FPS//60)} menit {int(total/FPS%60)} detik) — akan menyesuaikan audio narasi.",
           "Catatan: seluruh angka (900, 120, 65, 18, 200) berasal dari skenario. Angka pada indikator adalah TARGET SIMULASI, bukan hasil nyata.", "",
           "Pemeran: Nayla (Koordinator Respons), Natasha (Surveilans & Penilaian Situasi), Syifa (Sanitasi, Higiene & Lingkungan), Kayla (Logistik, Komunikasi Risiko & Pemantauan Warga). Pendukung: Narator, Warga, Kader.",
           "", "=" * 70]
    for s in scenes:
        src = SCENES[s["number"] - 1]
        a, b = s["startFrame"] / FPS, s["endFrame"] / FPS
        out += ["", f'ADEGAN {s["number"]} — {s["title"].upper()}  [{int(a//60)}:{int(a%60):02d}–{int(b//60)}:{int(b%60):02d}]',
                f'Visual: {src["visual"]}', ""]
        for l in s["lines"]:
            out.append(f'{l["speaker"].upper()}: {l["text"]}')
        out += ["", "-" * 70]
    with open(os.path.join(root, "naskah.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")
    print("scenes", len(scenes), "total frames", total, f"= {total/FPS:.1f}s")
    for s in scenes:
        print(s["id"], s["startFrame"], s["endFrame"], f'{s["durationFrames"]/FPS:.1f}s', max(len(x["text"]) for x in s["subtitles"]))
