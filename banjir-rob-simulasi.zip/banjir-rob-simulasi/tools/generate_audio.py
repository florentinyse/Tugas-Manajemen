#!/usr/bin/env python3
"""Membuat aset audio original (sintesis, bebas hak cipta) ke public/audio/*.wav.
Musik latar instrumental lembut, hujan, air, keramaian, pop, swoosh. Tidak ada sampel berhak cipta."""
import os, wave
import numpy as np

OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'audio')
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(19)

def save(name, x, sr):
    x = np.clip(x, -1, 1)
    with wave.open(os.path.join(OUT, name), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((x * 32767).astype('<i2').tobytes())
    print(name, f'{len(x)/sr:.1f}s')

def band_noise(n, sr, lo, hi, tilt=0.0):
    spec = rng.normal(size=n // 2 + 1) + 1j * rng.normal(size=n // 2 + 1)
    f = np.fft.rfftfreq(n, 1 / sr)
    shape = ((f >= lo) & (f <= hi)).astype(float)
    shape = np.convolve(shape, np.ones(9) / 9, mode='same')
    shape *= (np.maximum(f, 1) / 1000.0) ** (-tilt)
    x = np.fft.irfft(spec * shape, n)
    return x / (np.max(np.abs(x)) + 1e-9)

# ---------- musik latar (loop mulus) ----------
sr = 32000
bpm = 72
beat = 60 / bpm
chord_len = 4 * beat
prog = [  # nama akor -> nada (Hz)
    [130.81, 196.00, 246.94, 329.63],  # Cmaj7
    [110.00, 164.81, 196.00, 261.63],  # Am7
    [87.31, 130.81, 164.81, 220.00],   # Fmaj7
    [98.00, 146.83, 196.00, 246.94],   # G6/G
    [82.41, 123.47, 164.81, 246.94],   # Em7
    [110.00, 164.81, 196.00, 261.63],  # Am7
    [73.42, 110.00, 146.83, 220.00],   # Dm7
    [98.00, 146.83, 196.00, 293.66],   # G
    [130.81, 196.00, 246.94, 329.63],  # Cmaj7
    [87.31, 130.81, 164.81, 220.00],   # Fmaj7
    [110.00, 164.81, 196.00, 261.63],  # Am7
    [98.00, 146.83, 196.00, 246.94],   # G
]
total = int(len(prog) * chord_len * sr)
mus = np.zeros(total)
t_chord = np.arange(int(chord_len * sr)) / sr
def wrap_add(buf, start, sig):
    idx = (start + np.arange(len(sig))) % len(buf)
    np.add.at(buf, idx, sig)
for i, notes in enumerate(prog):
    start = int(i * chord_len * sr)
    env = np.minimum(t_chord / 0.9, 1) * np.minimum((chord_len - t_chord + 0.5) / 1.4, 1)
    env = np.clip(env, 0, 1)
    pad = np.zeros_like(t_chord)
    for fz in notes:
        pad += np.sin(2 * np.pi * fz * t_chord) + 0.35 * np.sin(2 * np.pi * 2 * fz * t_chord + 0.5) + 0.12 * np.sin(2 * np.pi * 3 * fz * t_chord)
    wrap_add(mus, start, 0.07 * pad * env)
    # arpeggio petik lembut
    arp = [notes[1] * 2, notes[2] * 2, notes[3] * 2, notes[2] * 2, notes[1] * 2, notes[3] * 2, notes[2] * 2, notes[3] * 2]
    for k, fz in enumerate(arp):
        s0 = start + int(k * beat / 2 * sr)
        tt = np.arange(int(1.6 * sr)) / sr
        pluck = np.sin(2 * np.pi * fz * tt) * np.exp(-tt * 3.2) * np.minimum(tt / 0.01, 1)
        wrap_add(mus, s0, 0.05 * pluck)
# reverb sederhana (comb circular)
for d, g in [(0.11, 0.35), (0.173, 0.3), (0.29, 0.25)]:
    mus = mus + g * np.roll(mus, int(d * sr))
mus = mus / np.max(np.abs(mus)) * 0.8
save('music-bed.wav', mus, sr)

# ---------- hujan ----------
sr2 = 22050
n = sr2 * 20
rain = band_noise(n, sr2, 1500, 9000, tilt=0.2) * 0.8
drops = np.zeros(n)
for _ in range(900):
    p = rng.integers(0, n - 400)
    tt = np.arange(300) / sr2
    drops[p:p + 300] += rng.uniform(0.1, 0.5) * np.sin(2 * np.pi * rng.uniform(2500, 6000) * tt) * np.exp(-tt * 900)
rain = rain + 0.5 * drops
save('rain.wav', rain / np.max(np.abs(rain)) * 0.9, sr2)

# ---------- air banjir (riak pelan) ----------
n = sr2 * 20
w = band_noise(n, sr2, 80, 900, tilt=0.6)
t = np.arange(n) / sr2
mod = 0.6 + 0.4 * np.sin(2 * np.pi * (3 / 20) * t) * np.sin(2 * np.pi * (5 / 20) * t + 1)
w2 = band_noise(n, sr2, 300, 2500, tilt=0.3) * (0.5 + 0.5 * np.sin(2 * np.pi * (7 / 20) * t + 2)) * 0.35
water = w * mod + w2
save('water.wav', water / np.max(np.abs(water)) * 0.9, sr2)

# ---------- keramaian / aktivitas lapangan (gumaman tanpa kata) ----------
n = sr2 * 24
t = np.arange(n) / sr2
m = band_noise(n, sr2, 180, 1400, tilt=0.4)
env = np.zeros(n)
for _ in range(60):
    c = rng.uniform(0, 24)
    wdt = rng.uniform(0.15, 0.5)
    env += np.exp(-0.5 * (((t - c + 12) % 24 - 12) / wdt) ** 2) * rng.uniform(0.3, 1)
env = env / env.max() * 0.8 + 0.2
save('murmur.wav', m * env / np.max(np.abs(m * env)) * 0.8, sr2)

# ---------- SFX ----------
tt = np.arange(int(0.25 * sr2)) / sr2
pop = np.sin(2 * np.pi * (520 + 700 * np.exp(-tt * 40)) * tt) * np.exp(-tt * 22)
save('pop.wav', pop * 0.9, sr2)
tt = np.arange(int(0.8 * sr2)) / sr2
sw = band_noise(len(tt), sr2, 400, 5000, tilt=0.0) * np.sin(np.pi * tt / 0.8) ** 2
save('swoosh.wav', sw * 0.6, sr2)
