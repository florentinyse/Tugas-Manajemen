#!/usr/bin/env python3
"""Membuat storyboard.pdf (1 halaman A4 landscape) dari public/timing.json."""
import io, json, os, sys
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from pypdf import PdfReader

ROOT = os.path.join(os.path.dirname(__file__), '..')
F = '/usr/share/fonts/truetype/liberation/'
pdfmetrics.registerFont(TTFont('LS', F + 'LiberationSansNarrow-Regular.ttf'))
pdfmetrics.registerFont(TTFont('LSB', F + 'LiberationSansNarrow-Bold.ttf'))
pdfmetrics.registerFontFamily('LS', normal='LS', bold='LSB', italic='LS', boldItalic='LSB')

t = json.load(open(os.path.join(ROOT, 'public', 'timing.json'), encoding='utf-8'))
TEAL, ORANGE, INK = colors.HexColor('#1f5550'), colors.HexColor('#e8793b'), colors.HexColor('#22202b')

VISUAL = {
 's01': 'Permukiman rumah panggung tepi sungai/rawa terendam; warga menyelamatkan barang; ±900 terdampak, ±200 di balai warga; 4 tokoh diperkenalkan.',
 's02': 'Peta situasi + penandaan titik masalah (sumur, septic tank, genangan, wilayah belum terjangkau) dan 8 masalah prioritas.',
 's03': 'Briefing di posko: diagram koordinasi, RNA, surveilans & peta, sumur diberi tanda, logistik, papan pembagian tugas.',
 's04': 'Lapangan & balai warga: pencatatan kasus, cuci tangan pakai sabun, sanitasi darurat, genangan, distribusi logistik, kader.',
 's05': 'Hari ke-2: laporan kader, alur penilaian ulang (gejala → pemeriksaan → rujukan), peta risiko diperbarui.',
 's06': 'Evaluasi 48–72 jam: alur pemantauan & pelaporan, air/sanitasi/vektor, logistik, daftar tindak lanjut.',
 's07': 'Tiga kartu indikator: definisi, cara ukur, target simulasi (cincin putus-putus = target, bukan hasil).',
 's08': 'Dua kartu risiko beserta lima mitigasi masing-masing; tim berdiri di bawah kartu.',
 's09': 'Tim, kader, dan warga bersama di depan balai warga; enam butir ringkasan dan pesan penutup.',
}
RESPONS = {
 's01': 'Identifikasi situasi, dampak awal, kondisi darurat.',
 's02': 'Penentuan masalah prioritas & kelompok rentan.',
 's03': 'Koordinasi lintas pihak, RNA, surveilans awal, pemetaan, pengamanan air, prioritas rentan, pembagian tugas.',
 's04': 'Surveilans harian, komunikasi risiko, air aman, CTPS, sanitasi/limbah, vektor, logistik, kader.',
 's05': 'Penilaian ulang, penguatan surveilans demam, rujukan ke Puskesmas, penyesuaian logistik.',
 's06': 'Pemantauan berkala, pelaporan, evaluasi air aman, sanitasi, vektor, tindak lanjut.',
 's07': '3 indikator pemantauan (target simulasi).',
 's08': '2 risiko pelaksanaan + mitigasi.',
 's09': 'Kesimpulan kebutuhan respons & pesan penutup.',
}
CORE = {
 's01': '<b>Narator:</b> Pasang tinggi + hujan menggenangi permukiman >24 jam; ±900 terdampak, ±200 di balai warga.<br/><b>Nayla:</b> “Kita punya 72 jam pertama.” Natasha, Syifa, Kayla memperkenalkan perannya.',
 's02': '<b>Nayla:</b> “Kita tentukan masalah prioritas.”<br/><b>Syifa:</b> “Air sumur berubah warna dan berbau.” <b>Natasha:</b> diare & keluhan kulit. <b>Kayla:</b> air minum ±1 hari.',
 's03': '<b>Nayla:</b> “Fase 0 sampai 24 jam,” koordinasi desa–Puskesmas–kader–relawan. <b>Natasha:</b> RNA & surveilans awal. <b>Syifa:</b> sumur ditandai. <b>Kayla:</b> logistik ke balai warga.',
 's04': '<b>Natasha:</b> kasus dicatat harian. <b>Syifa:</b> CTPS, air aman, sanitasi darurat. <b>Kayla:</b> komunikasi risiko & kader. <b>Warga:</b> “Apakah air sumur boleh dipakai memasak?” <b>Syifa:</b> “Sebaiknya jangan, Bu.”',
 's05': '<b>Kader:</b> “Ada beberapa warga demam…” <b>Nayla:</b> “Demam adalah gejala yang perlu dinilai lebih lanjut.” <b>Natasha:</b> data & rujuk ke Puskesmas.',
 's06': '<b>Natasha:</b> pemantauan berkala & pelaporan. <b>Syifa:</b> air aman dievaluasi. <b>Kayla:</b> logistik dihitung ulang. <b>Nayla:</b> tindak lanjut setelah fase respons awal.',
 's07': '<b>Narator:</b> “Angkanya adalah target simulasi, bukan hasil nyata.” <b>Natasha, Syifa, Kayla</b> menjelaskan indikator 1, 2, 3.',
 's08': '<b>Nayla:</b> risiko 1 (wilayah sulit dijangkau) dan mitigasinya. <b>Kayla:</b> risiko 2 (air aman & logistik terbatas) dan mitigasinya.',
 's09': '<b>Nayla & Natasha:</b> kebutuhan respons banjir rob. <b>Narator:</b> “Di lahan basah, kesehatan dijaga bersama warga.”',
}
def core(s):
    return CORE[s['id']]

def mmss(f):
    s = f / t['fps']; return f"{int(s // 60)}:{int(s % 60):02d}"

def build(fs):
    def st(**k):
        d = dict(fontName='LS', fontSize=fs, leading=fs * 1.17, textColor=INK)
        d.update(k)
        return ParagraphStyle('x', **d)
    esc = lambda x: x.replace('&amp;', '&').replace('&', '&amp;')
    P = lambda x, **k: Paragraph(esc(x), st(**k))
    H = lambda x: Paragraph(esc(f'<b>{x}</b>'), st(textColor=colors.white))
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=20, rightMargin=20, topMargin=16, bottomMargin=14)
    el = []
    el.append(Paragraph(f'<b>STORYBOARD VIDEO SIMULASI — {t["title"]}</b>'.replace('&', '&amp;'), ParagraphStyle('t', fontName='LSB', fontSize=fs + 3.2, leading=fs + 5, textColor=TEAL)))
    el.append(Spacer(1, 2))
    dur = t['totalFrames'] / t['fps']
    el.append(P('<b>Skenario 5 — Banjir Rob dan Penyakit Berbasis Lingkungan</b> (Manajemen Bencana di Lingkungan Lahan Basah dan KLB). '
                'Air pasang tinggi + hujan menggenangi permukiman sungai/rawa >24 jam; ±900 penduduk terdampak (120 anak, 65 lansia, 18 ibu hamil); '
                '±200 orang di balai warga; septic tank & saluran terendam, air sumur keruh/berbau, diare & keluhan kulit, genangan berpotensi sarang nyamuk, '
                'air minum kemasan ±1 hari, kader belum menjangkau semua wilayah; hari ke-2 mulai ada demam. '
                f'<b>Format:</b> MP4 1920×1080, 30 fps, kartun 2D SVG, estimasi {int(dur // 60)} mnt {int(dur % 60)} dtk. '
                '<i>Angka = dari skenario; target indikator = target simulasi, bukan hasil nyata.</i>'))
    el.append(Spacer(1, 3))
    rows = [[H('No'), H('Adegan & durasi'), H('Visual'), H('Narasi / dialog inti'), H('Respons kesehatan masyarakat'), H('Perkembangan situasi')]]
    dev = {'s01': 'Awal kejadian (jam 0)', 's02': 'Jam 0: masalah teridentifikasi', 's03': 'Jam 0–24', 's04': 'Jam 24–36',
           's05': 'Hari ke-2: demam & genangan menetap → strategi diubah', 's06': 'Jam 48–72', 's07': 'Jam 72', 's08': 'Jam 72', 's09': 'Jam 72 / penutup'}
    for s in t['scenes']:
        d = (s['endFrame'] - s['startFrame']) / t['fps']
        rows.append([P(str(s['number'])), P(f"<b>{s['title']}</b><br/>{mmss(s['startFrame'])}–{mmss(s['endFrame'])} ({d:.0f} dtk)"),
                     P(VISUAL[s['id']]), P(core(s)), P(RESPONS[s['id']]), P(dev[s['id']])])
    cw = [18, 106, 196, 232, 170, 78]
    tb = Table(rows, colWidths=cw, repeatRows=1)
    tb.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), TEAL), ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#9aa5b1')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f3f7f6')]),
        ('LEFTPADDING', (0, 0), (-1, -1), 2.5), ('RIGHTPADDING', (0, 0), (-1, -1), 2.5), ('TOPPADDING', (0, 0), (-1, -1), 1.3), ('BOTTOMPADDING', (0, 0), (-1, -1), 1.3)]))
    el.append(tb)
    el.append(Spacer(1, 4))
    ind = [H('3 INDIKATOR PEMANTAUAN (target simulasi)'),
        P('<b>1. Surveilans kesehatan:</b> % warga terdampak/pengungsi yang terdata & dipantau dalam 72 jam. Ukur: terdata ÷ perkiraan terdampak × 100%. Target ≥90%.<br/>'
          '<b>2. Air minum aman:</b> % lokasi pengungsian/rumah tangga prioritas dengan akses air minum aman sesuai kebutuhan. Ukur: terlayani ÷ prioritas × 100%. Target ≥90%.<br/>'
          '<b>3. Respons penyakit:</b> % laporan diare, keluhan kulit, atau demam yang ditindaklanjuti (penilaian/rujukan). Ukur: ditindaklanjuti ÷ semua laporan × 100%. Target ≥95%.')]
    rsk = [H('2 RISIKO PELAKSANAAN & MITIGASI'),
        P('<b>Risiko 1 — Wilayah sulit dijangkau (genangan/akses).</b> Mitigasi: kader lokal, pemetaan wilayah, prioritas akses, distribusi logistik bertahap, koordinasi relawan & pemerintah setempat.<br/>'
          '<b>Risiko 2 — Air minum aman & logistik terbatas.</b> Mitigasi: prioritas distribusi sesuai kebutuhan, cari sumber tambahan, koordinasi lintas sektor, pantau stok berkala, edukasi pengolahan air aman.')]
    rol = [H('PEMBAGIAN PERAN 4 TOKOH (perempuan, desain konsisten)'),
        P('<b>Nayla</b> (rompi oranye, kuncir) — Koordinator: koordinasi, pembagian tugas, prioritas, penyesuaian strategi.<br/>'
          '<b>Natasha</b> (rompi biru, kacamata, clipboard) — Surveilans & RNA: pendataan, pencatatan, pelaporan, rujukan.<br/>'
          '<b>Syifa</b> (rompi hijau, topi, sarung tangan) — Sanitasi, higiene & lingkungan: air aman, CTPS, sanitasi darurat, genangan.<br/>'
          '<b>Kayla</b> (rompi ungu, hijab merah muda, tas) — Logistik, komunikasi risiko & pemantauan warga: distribusi, kelompok rentan, kader.')]
    box = Table([[ind[0], rsk[0], rol[0]], [ind[1], rsk[1], rol[1]]], colWidths=[266, 266, 268])
    box.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), ORANGE), ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#9aa5b1')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LEFTPADDING', (0, 0), (-1, -1), 3), ('RIGHTPADDING', (0, 0), (-1, -1), 3),
        ('TOPPADDING', (0, 0), (-1, -1), 1.5), ('BOTTOMPADDING', (0, 0), (-1, -1), 1.5)]))
    el.append(box)
    doc.build(el)
    buf.seek(0)
    return buf

for fs in [9.0, 8.6, 8.2, 7.8, 7.4, 7.1, 6.8, 6.5, 6.2, 5.9, 5.6]:
    b = build(fs)
    n = len(PdfReader(b).pages)
    print('font', fs, 'pages', n)
    if n == 1:
        open(os.path.join(ROOT, 'storyboard.pdf'), 'wb').write(b.getvalue())
        break
else:
    sys.exit('storyboard tidak muat 1 halaman')
