# Simulasi Respons Kesehatan Masyarakat dalam 72 Jam Pertama Banjir Rob

Project **Remotion** (React + TypeScript + SVG) untuk video tugas *Manajemen Bencana di Lingkungan Lahan Basah dan KLB* — **Skenario 5: Banjir Rob dan Penyakit Berbasis Lingkungan**.

- Format: MP4, landscape 16:9, 1920 × 1080, 30 fps, kartun 2D flat vector (SVG)
- Durasi awal (estimasi): ± 4 menit 9 detik. Durasi akan mengikuti audio narasi setelah direkam (lihat bagian 5).
- 4 tokoh utama perempuan: **Nayla** (koordinator), **Natasha** (surveilans & RNA), **Syifa** (sanitasi, higiene, lingkungan), **Kayla** (logistik, komunikasi risiko, pemantauan warga).
- Semua aset visual dibuat dengan kode (SVG/CSS) dan audio sintesis original. Tidak ada aset berlisensi, tidak butuh internet saat render.

> **Catatan status:** project ini disusun tanpa merender video apa pun (sesuai ketentuan tugas). Pemeriksaan TypeScript saat penyusunan dijalankan terhadap *stub* tipe `react`/`remotion` karena paket asli tidak dapat dipasang di lingkungan penyusun. Jalankan `npm run typecheck` setelah `npm install` untuk pemeriksaan penuh, dan lihat hasilnya di Remotion Studio sebelum render akhir.

## 1. Struktur project

```
banjir-rob-simulasi/
├─ public/
│  ├─ timing.json            ← SUMBER TIMING UTAMA (adegan, kalimat, subtitle)
│  ├─ audio-manifest.json    ← dibuat otomatis oleh `npm run prepare:audio`
│  └─ audio/
│     ├─ music-bed.wav, rain.wav, water.wav, murmur.wav, pop.wav, swoosh.wav  (sintesis original)
│     └─ narasi/             ← LETAKKAN rekaman narasi di sini (scene-01.mp3 ... scene-09.mp3)
├─ src/
│  ├─ index.ts, Root.tsx, Main.tsx   ← registrasi komposisi "BanjirRob"
│  ├─ scenes/                ← Scene1Pembuka ... Scene9Penutup + index.ts (pemetaan sceneKey)
│  ├─ components/            ← Person (karakter), Characters, Backdrops, Buildings, Water, Sky,
│  │                           Infographic, Briefing, CameraRig, Subtitle, Hud, AudioTracks, SceneShell, Icons
│  ├─ config/                ← characters.ts (desain 4 tokoh), audio.ts (volume), credits.ts (teks judul/penutup)
│  ├─ lib/                   ← timing.tsx (hook sinkron naskah), anim.ts
│  └─ assets/theme.ts        ← palet warna & konstanta
├─ scripts/                  ← prepare, validate-timing, build-srt, sync-timing, tts-espeak
├─ tools/                    ← generate_timing.py, generate_audio.py, make_storyboard.py (pembuat file pendukung)
├─ naskah.txt, narasi.srt, storyboard.pdf
├─ package.json, tsconfig.json, remotion.config.ts
```

## 2. Persyaratan & instalasi

1. **Node.js 18 atau lebih baru** (disarankan versi LTS). Unduh dari https://nodejs.org lalu instal (Windows/macOS: installer; Linux: paket distro atau `nvm`). Cek: `node -v` dan `npm -v`.
2. Di folder project jalankan:
   ```bash
   npm install
   ```
   Pertama kali render, Remotion mengunduh Chrome Headless otomatis (perlu internet satu kali).

## 3. Menjalankan

| Perintah | Fungsi |
|---|---|
| `npm run studio` | Buka Remotion Studio untuk pratinjau interaktif |
| `npm run render` | Render MP4 bersuara → **`out/banjir-rob-simulasi.mp4`** |
| `npm run typecheck` | Validasi TypeScript (`tsc --noEmit`) |
| `npm run validate` | Validasi timing + TypeScript |
| `npm run srt` | Buat ulang `narasi.srt` dari `public/timing.json` |
| `npm run sync` | Sesuaikan timing dengan durasi rekaman narasi |

`npm run render` otomatis memindai audio narasi, memvalidasi timing, lalu merender. MP4 hasil render memuat musik latar, ambience hujan/air/keramaian, SFX lembut, dan narasi (jika sudah ada).

## 4. Mengubah isi

- **Timing adegan / kalimat / subtitle:** edit `public/timing.json` (tanpa menyentuh React). Struktur: `scenes[] → {id, title, sceneKey, startFrame, endFrame, durationFrames, hourStart, hourEnd, lines[], subtitles[]}`; 30 frame = 1 detik. Aturan: adegan harus bersambung tanpa celah (`startFrame` = `endFrame` adegan sebelumnya), dan `totalFrames` = `endFrame` adegan terakhir. Cek dengan `npm run validate:timing`.
- **Teks subtitle:** ubah `lines[].text` (untuk naskah) dan `subtitles[].text` (yang tampil di layar, maks. 2 baris ≈ 90 karakter) di `public/timing.json`, lalu `npm run srt`.
- **Naskah ulang dari awal:** ubah teks di `tools/generate_timing.py` lalu `python3 tools/generate_timing.py` (menimpa `timing.json` dan `naskah.txt`).
- **Visual:** setiap adegan ada di `src/scenes/`. Animasi panel dipicu oleh urutan kalimat (`cue.appear(i)` = saat kalimat ke-i mulai diucapkan), jadi visual mengikuti timing. Kamera diatur di `CameraRig keys` (`line: n` = awal kalimat ke-n).
- **Tokoh:** `src/config/characters.ts` (warna rompi, gaya rambut, hijab, kacamata, alat bantu). Mis. ubah `hairStyle: 'hijab'` menjadi `'bob'`/`'braid'`/`'ponytail'`/`'bun'` agar sesuai penampilan anggota kelompok.
- **Judul, nama kelompok/kampus pada kartu pembuka:** `src/config/credits.ts`.
- **Volume audio:** `src/config/audio.ts` (narasi 1.0, musik 0.10, ambience lebih rendah).

## 5. Memasukkan audio narasi

1. Rekam narasi per adegan dan simpan di `public/audio/narasi/` dengan nama: `scene-01.mp3` … `scene-09.mp3` (juga boleh `.wav`, `.m4a`, `.ogg`). Satu file = seluruh naskah adegan tersebut (baca sesuai `naskah.txt`, mulai langsung dari kalimat pertama).
2. `npm run sync` — mengukur durasi tiap rekaman (memakai `remotion ffprobe`) dan menyesuaikan `timing.json` agar kalimat, subtitle, dan durasi adegan mengikuti rekaman.
3. `npm run srt` — perbarui `narasi.srt`.
4. `npm run studio` untuk memeriksa, lalu `npm run render`.

Adegan tanpa file rekaman tetap dirender (tanpa suara narasi). *Opsional:* `npm run tts` membuat draf suara memakai eSpeak NG bila terpasang (suara robotik; sebaiknya diganti rekaman kelompok).

## 6. Catatan isi simulasi

- Fakta dasar skenario tidak diubah. Angka yang tampil (±900, 120 anak, 65 lansia, 18 ibu hamil, ±200 di balai warga, air minum ±1 hari) berasal dari skenario.
- Target indikator (≥90%, ≥90%, ≥95%) adalah **target simulasi**; tidak ada hasil capaian yang dikarang. Cincin putus-putus pada kartu indikator menandakan target, bukan hasil.
- Demam digambarkan sebagai gejala yang perlu dinilai lebih lanjut (penilaian → pemeriksaan → rujukan), bukan diagnosis dengue.
- Jam pada garis waktu 72 jam adalah penanda alur simulasi, bukan data kejadian.
