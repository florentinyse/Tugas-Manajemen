import React from 'react';
import {C, FONT} from '../assets/theme';
import {useCue} from '../lib/timing';

/** Label adegan (kiri atas) + garis waktu 72 jam (kanan atas). */
export const Hud: React.FC = () => {
  const cue = useCue();
  const sc = cue.scene;
  const hour = sc.hourStart + (sc.hourEnd - sc.hourStart) * cue.p;
  const pct = Math.max(0, Math.min(100, (hour / 72) * 100));
  const seg = ['0–24 jam', '24–48 jam', '48–72 jam'];
  return (
    <>
      <div
        style={{
          position: 'absolute',
          left: 36,
          top: 24,
          padding: '10px 22px',
          background: 'rgba(14,18,28,0.72)',
          border: '3px solid rgba(255,255,255,0.85)',
          borderRadius: 16,
          color: '#fff',
          fontFamily: FONT,
          fontSize: 24,
          fontWeight: 700,
        }}
      >
        <span style={{color: C.mustard}}>ADEGAN {sc.number}</span> · {sc.title}
      </div>
      <div
        style={{
          position: 'absolute',
          right: 36,
          top: 20,
          width: 520,
          padding: '8px 18px 12px',
          background: 'rgba(14,18,28,0.72)',
          border: '3px solid rgba(255,255,255,0.85)',
          borderRadius: 16,
          fontFamily: FONT,
          color: '#fff',
        }}
      >
        <div style={{display: 'flex', justifyContent: 'space-between', fontSize: 18, fontWeight: 700, marginBottom: 6}}>
          <span>SIMULASI 72 JAM PERTAMA</span>
          <span style={{color: C.mustard}}>JAM KE-{Math.round(hour)}</span>
        </div>
        <div style={{position: 'relative', display: 'flex', gap: 4}}>
          {seg.map((s, i) => (
            <div key={s} style={{flex: 1, textAlign: 'center', fontSize: 14, fontWeight: 600}}>
              <div
                style={{
                  height: 12,
                  borderRadius: 6,
                  marginBottom: 3,
                  background: pct >= (i + 1) * 33.33 ? C.green : pct > i * 33.33 ? C.mustard : 'rgba(255,255,255,0.28)',
                }}
              />
              {s}
            </div>
          ))}
          <div style={{position: 'absolute', left: `${pct}%`, top: -6, width: 4, height: 24, marginLeft: -2, background: '#fff', borderRadius: 2}} />
        </div>
      </div>
    </>
  );
};
