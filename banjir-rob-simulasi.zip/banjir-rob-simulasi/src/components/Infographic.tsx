import React from 'react';
import {C, FONT, OUTLINE, SHADOW} from '../assets/theme';
import {clamp01} from '../lib/anim';
import {Icon, IconName} from './Icons';

/** Panel infografis (kartu) dengan header berwarna. t = 0..1 untuk animasi masuk. */
export const PanelShell: React.FC<{
  t: number;
  title: string;
  icon: IconName;
  color: string;
  x?: number;
  y?: number;
  w?: number;
  h?: number;
  titleSize?: number;
  children?: React.ReactNode;
}> = ({t, title, icon, color, x = 960, y = 130, w = 900, h = 730, titleSize = 34, children}) => {
  if (t <= 0.01) return null;
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: w,
        height: h,
        opacity: t,
        transform: `translateY(${(1 - t) * 30}px)`,
        background: C.paper,
        border: `${OUTLINE}px solid ${C.ink}`,
        borderRadius: 26,
        boxShadow: SHADOW,
        overflow: 'hidden',
        fontFamily: FONT,
        color: C.ink,
      }}
    >
      <div style={{height: 84, background: color, display: 'flex', alignItems: 'center', gap: 16, padding: '0 28px', borderBottom: `${OUTLINE}px solid ${C.ink}`}}>
        <Icon name={icon} size={54} bg="#fff" color={color} />
        <div style={{fontSize: titleSize, fontWeight: 800, color: '#fff', letterSpacing: 0.5}}>{title}</div>
      </div>
      <div style={{padding: '22px 30px', height: h - 84, boxSizing: 'border-box', position: 'relative'}}>{children}</div>
    </div>
  );
};

export type RowItem = {icon: IconName; text: string; sub?: string; color?: string};

export const IconRow: React.FC<{item: RowItem; t: number; size?: number; fontSize?: number}> = ({item, t, size = 56, fontSize = 30}) => (
  <div style={{display: 'flex', alignItems: 'center', gap: 18, opacity: t, transform: `translateX(${(1 - t) * 40}px)`}}>
    <div style={{width: size + 14, height: size + 14, borderRadius: '50%', background: item.color ?? '#e6eef3', border: `3px solid ${C.ink}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0}}>
      <Icon name={item.icon} size={size} />
    </div>
    <div>
      <div style={{fontSize, fontWeight: 700, lineHeight: 1.2}}>{item.text}</div>
      {item.sub ? <div style={{fontSize: fontSize * 0.72, color: C.gray, fontWeight: 600, marginTop: 2}}>{item.sub}</div> : null}
    </div>
  </div>
);

/** Panel daftar bertingkat (baris muncul berurutan, k = 0..1). */
export const ListPanel: React.FC<{
  t: number;
  k: number;
  title: string;
  icon: IconName;
  color: string;
  rows: RowItem[];
  footer?: string;
  fontSize?: number;
}> = ({t, k, title, icon, color, rows, footer, fontSize = 30}) => (
  <PanelShell t={t} title={title} icon={icon} color={color}>
    <div style={{display: 'flex', flexDirection: 'column', gap: 22}}>
      {rows.map((r, i) => (
        <IconRow key={r.text} item={r} t={clamp01(k * (rows.length + 1) - i)} fontSize={fontSize} />
      ))}
    </div>
    {footer ? (
      <div style={{position: 'absolute', left: 30, right: 30, bottom: 22, padding: '12px 20px', background: '#fff3cf', border: `3px solid ${C.ink}`, borderRadius: 16, fontSize: 24, fontWeight: 700, opacity: clamp01(k * 3 - 1.4)}}>
        {footer}
      </div>
    ) : null}
  </PanelShell>
);

export type FlowStep = {icon: IconName; label: string; sub?: string};

const Arrow: React.FC = () => (
  <svg width={34} height={34} viewBox="0 0 34 34" style={{flexShrink: 0}}>
    <path d="M4 17 H26 M18 8 L28 17 L18 26" fill="none" stroke={C.ink} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const FlowPanel: React.FC<{t: number; k: number; title: string; icon: IconName; color: string; steps: FlowStep[]; note?: string}> = ({t, k, title, icon, color, steps, note}) => (
  <PanelShell t={t} title={title} icon={icon} color={color}>
    <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 40}}>
      {steps.map((s, i) => {
        const st = clamp01(k * (steps.length + 1) - i);
        return (
          <React.Fragment key={s.label}>
            <div style={{width: 170, textAlign: 'center', opacity: st, transform: `scale(${0.85 + 0.15 * st})`}}>
              <div style={{width: 112, height: 112, margin: '0 auto 14px', borderRadius: 24, background: '#e6eef3', border: `4px solid ${C.ink}`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                <Icon name={s.icon} size={72} />
              </div>
              <div style={{fontSize: 26, fontWeight: 800, lineHeight: 1.15}}>{s.label}</div>
              {s.sub ? <div style={{fontSize: 19, color: C.gray, fontWeight: 600, marginTop: 4}}>{s.sub}</div> : null}
            </div>
            {i < steps.length - 1 ? <div style={{opacity: st}}><Arrow /></div> : null}
          </React.Fragment>
        );
      })}
    </div>
    {note ? (
      <div style={{position: 'absolute', left: 30, right: 30, bottom: 24, padding: '14px 22px', background: '#fff3cf', border: `3px solid ${C.ink}`, borderRadius: 16, fontSize: 26, fontWeight: 700, opacity: clamp01(k * 3 - 1.6)}}>
        {note}
      </div>
    ) : null}
  </PanelShell>
);

export type Tile = {icon: IconName; big: string; label: string; color: string};

export const TilesPanel: React.FC<{t: number; k: number; title: string; icon: IconName; color: string; tiles: Tile[]; note?: string}> = ({t, k, title, icon, color, tiles, note}) => (
  <PanelShell t={t} title={title} icon={icon} color={color}>
    <div style={{display: 'flex', gap: 22, marginTop: 20}}>
      {tiles.map((tile, i) => {
        const st = clamp01(k * (tiles.length + 1) - i);
        return (
          <div key={tile.label} style={{flex: 1, height: 360, borderRadius: 24, background: tile.color, border: `4px solid ${C.ink}`, padding: 20, boxSizing: 'border-box', textAlign: 'center', opacity: st, transform: `translateY(${(1 - st) * 30}px)`}}>
            <div style={{display: 'flex', justifyContent: 'center', marginBottom: 14}}>
              <Icon name={tile.icon} size={96} bg="#fff" />
            </div>
            <div style={{fontSize: 34, fontWeight: 800, color: '#fff', lineHeight: 1.15, textShadow: '0 2px 0 rgba(0,0,0,0.25)'}}>{tile.big}</div>
            <div style={{fontSize: 24, fontWeight: 600, color: '#fff', marginTop: 10, lineHeight: 1.25}}>{tile.label}</div>
          </div>
        );
      })}
    </div>
    {note ? (
      <div style={{position: 'absolute', left: 30, right: 30, bottom: 24, padding: '14px 22px', background: '#fff3cf', border: `3px solid ${C.ink}`, borderRadius: 16, fontSize: 26, fontWeight: 700, opacity: clamp01(k * 3 - 1.6)}}>
        {note}
      </div>
    ) : null}
  </PanelShell>
);

/** Chip informasi kecil (mis. keterangan aktivitas di lapangan). */
export const Chip: React.FC<{icon: IconName; text: string; t: number; color?: string}> = ({icon, text, t, color = '#fff'}) => (
  <div style={{display: 'flex', alignItems: 'center', gap: 12, padding: '8px 22px 8px 10px', background: color, border: `3.5px solid ${C.ink}`, borderRadius: 40, boxShadow: '5px 5px 0 rgba(34,32,43,0.22)', fontFamily: FONT, fontSize: 28, fontWeight: 700, color: C.ink, opacity: t, transform: `translateY(${(1 - t) * -20}px)`}}>
    <Icon name={icon} size={46} />
    {text}
  </div>
);

/** Peta situasi sederhana. Penandaan muncul sesuai nilai reveal (0..1). */
export const SettlementMap: React.FC<{
  width: number;
  reveal: {balai?: number; sumur?: number; septic?: number; nyamuk?: number; unreached?: number; rentan?: number; fever?: number};
}> = ({width, reveal}) => {
  const r = {balai: 1, sumur: 0, septic: 0, nyamuk: 0, unreached: 0, rentan: 0, fever: 0, ...reveal};
  const houses: [number, number][] = [[90, 250], [180, 310], [270, 240], [150, 400], [330, 370], [420, 250], [560, 330], [640, 250], [700, 380], [250, 470], [500, 450], [380, 500]];
  const label = (x: number, y: number, text: string, o = 1) => (
    <text x={x} y={y} fontSize={20} fontWeight={800} fill={C.ink} fontFamily={FONT} textAnchor="middle" stroke="#fff" strokeWidth={5} paintOrder="stroke" opacity={o}>
      {text}
    </text>
  );
  return (
    <svg width={width} height={(width * 560) / 900} viewBox="0 0 900 560" style={{display: 'block'}}>
      <rect x={2} y={2} width={896} height={556} rx={22} fill="#dbe8b8" stroke={C.ink} strokeWidth={4} />
      <path d="M-10 130 C200 60 380 190 560 140 S820 120 910 190" fill="none" stroke="#6fb0d4" strokeWidth={74} />
      {label(130, 60, 'Sungai')}
      <ellipse cx={730} cy={470} rx={170} ry={80} fill="#8fc79a" stroke={C.ink} strokeWidth={3} strokeDasharray="2 0" />
      {[660, 700, 740, 780].map((rx, i) => (
        <path key={rx} d={`M${rx} 490 q-6 -34 -14 -50 M${rx} 490 q6 -30 12 -46`} fill="none" stroke="#3f7a4b" strokeWidth={4} strokeLinecap="round" opacity={0.9} transform={`translate(0,${i % 2 ? -10 : 8})`} />
      ))}
      {label(730, 540, 'Rawa')}
      {[[140, 330, 110, 60], [450, 330, 130, 70], [330, 440, 120, 60], [640, 300, 100, 60]].map(([cx, cy, rx, ry]) => (
        <ellipse key={`${cx}${cy}`} cx={cx} cy={cy} rx={rx} ry={ry} fill={C.flood} opacity={0.5} />
      ))}
      {houses.map(([hx, hy], i) => (
        <g key={i} transform={`translate(${hx},${hy})`}>
          <path d="M-18 -4 L0 -20 L18 -4 Z" fill={i % 2 ? C.red : C.teal} stroke={C.ink} strokeWidth={2.5} />
          <rect x={-14} y={-4} width={28} height={20} fill={C.woodLight} stroke={C.ink} strokeWidth={2.5} />
        </g>
      ))}
      <g transform="translate(470,330)">
        <path d="M-52 -14 L-30 -50 L30 -50 L52 -14 Z" fill="#a8452f" stroke={C.ink} strokeWidth={3.5} />
        <rect x={-46} y={-14} width={92} height={46} fill="#e8d4a8" stroke={C.ink} strokeWidth={3.5} />
        {label(0, 62, 'Balai warga ±200 orang', r.balai)}
      </g>
      {r.rentan > 0.01 ? <circle cx={470} cy={332} r={80 + Math.sin(r.rentan * 6) * 0} fill="none" stroke={C.orange} strokeWidth={6} strokeDasharray="10 8" opacity={r.rentan} /> : null}
      {[[250, 300], [330, 420], [610, 250]].map(([sx, sy], i) => (
        <g key={`w${i}`} transform={`translate(${sx},${sy}) scale(${0.35 + 0.65 * r.sumur})`} opacity={r.sumur}>
          <circle r={24} fill="#fff" stroke={C.ink} strokeWidth={3.5} />
          <circle r={11} fill={C.flood} stroke={C.ink} strokeWidth={2.5} />
          <path d="M-20 -20 L20 20 M20 -20 L-20 20" stroke={C.red} strokeWidth={6} strokeLinecap="round" />
        </g>
      ))}
      {[[150, 380], [420, 420]].map(([sx, sy], i) => (
        <g key={`s${i}`} transform={`translate(${sx},${sy}) scale(${0.35 + 0.65 * r.septic})`} opacity={r.septic}>
          <rect x={-22} y={-16} width={44} height={32} rx={6} fill={C.mustard} stroke={C.ink} strokeWidth={3} />
          <text y={7} textAnchor="middle" fontSize={20} fontWeight={800} fontFamily={FONT} fill={C.ink}>ST</text>
        </g>
      ))}
      {[[200, 250], [560, 380], [720, 300]].map(([mx, my], i) => (
        <g key={`m${i}`} transform={`translate(${mx},${my + Math.sin(i) * 3}) scale(0.9)`} opacity={r.nyamuk}>
          <circle r={26} fill="#fff" stroke={C.ink} strokeWidth={3} />
          <g transform="translate(-24,-24)"><Icon name="mosquito" size={48} color="#444" /></g>
        </g>
      ))}
      {[[780, 250, 90, 70], [100, 500, 90, 50]].map(([ux, uy, rx, ry], i) => (
        <g key={`u${i}`} opacity={r.unreached}>
          <ellipse cx={ux} cy={uy} rx={rx} ry={ry} fill="rgba(209,73,63,0.12)" stroke={C.red} strokeWidth={5} strokeDasharray="12 9" />
          <text x={ux} y={uy + 14} textAnchor="middle" fontSize={44} fontWeight={800} fill={C.red} fontFamily={FONT}>?</text>
        </g>
      ))}
      {r.unreached > 0.01 ? label(780, 335, 'Belum terjangkau', r.unreached) : null}
      {r.fever > 0.01
        ? [[780, 215], [120, 480]].map(([fx, fy], i) => (
            <g key={`f${i}`} transform={`translate(${fx - 20},${fy - 52})`} opacity={r.fever}>
              <circle cx={20} cy={20} r={22} fill="#fff" stroke={C.ink} strokeWidth={3} />
              <g transform="translate(-2,-2)"><Icon name="thermo" size={44} /></g>
            </g>
          ))
        : null}
    </svg>
  );
};
