import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {FONT} from '../assets/theme';
import {clamp01} from '../lib/anim';
import {useScene} from '../lib/timing';
import {RainLayer} from './Sky';

/** Pembungkus adegan: fade masuk/keluar singkat, hujan tingkat layar. */
export const SceneShell: React.FC<{children: React.ReactNode; rain?: number; bg?: string}> = ({children, rain = 0, bg = '#10202e'}) => {
  const f = useCurrentFrame();
  const scene = useScene();
  const op = Math.min(clamp01(f / 10), clamp01((scene.durationFrames - f) / 10));
  return (
    <AbsoluteFill style={{backgroundColor: bg, fontFamily: FONT}}>
      <AbsoluteFill style={{opacity: op}}>
        {children}
        <RainLayer intensity={rain} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

/** Lapisan layar penuh (SVG 1920x1080) untuk adegan tanpa kamera. */
export const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute', left: 0, top: 0, display: 'block'}}>
    {children}
  </svg>
);
