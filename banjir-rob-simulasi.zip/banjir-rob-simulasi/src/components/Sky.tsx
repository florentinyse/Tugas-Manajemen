import React from 'react';
import {interpolateColors, useCurrentFrame} from 'remotion';
import {W, H} from '../assets/theme';

/** Langit gradasi + awan. weather: 0 cerah ... 1 hujan lebat. */
export const SkyBackground: React.FC<{w: number; h?: number; weather: number}> = ({w, h = 620, weather}) => {
  const f = useCurrentFrame();
  const top = interpolateColors(weather, [0, 1], ['#78b8e8', '#56657a']);
  const bot = interpolateColors(weather, [0, 1], ['#e6f3fa', '#a7b3be']);
  const cloud = interpolateColors(weather, [0, 1], ['#ffffff', '#8a97a4']);
  const n = Math.ceil(w / 420);
  return (
    <g>
      <defs>
        <linearGradient id="skyG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={top} />
          <stop offset="1" stopColor={bot} />
        </linearGradient>
      </defs>
      <rect x={0} y={0} width={w} height={h} fill="url(#skyG)" />
      {Array.from({length: n}).map((_, i) => {
        const cx = ((i * 420 + 100 + f * (0.25 + (i % 3) * 0.1)) % (w + 300)) - 150;
        const cy = 80 + ((i * 57) % 160);
        const s = 0.8 + (i % 3) * 0.3;
        return (
          <g key={i} transform={`translate(${cx},${cy}) scale(${s})`} fill={cloud} opacity={0.95}>
            <ellipse cx={0} cy={0} rx={90} ry={32} />
            <circle cx={-30} cy={-22} r={34} />
            <circle cx={22} cy={-30} r={40} />
            <circle cx={62} cy={-8} r={28} />
          </g>
        );
      })}
    </g>
  );
};

/** Hujan: overlay tingkat layar (di atas kamera). */
export const RainLayer: React.FC<{intensity: number}> = ({intensity}) => {
  const f = useCurrentFrame();
  if (intensity <= 0.01) return null;
  const n = Math.round(150 * intensity);
  return (
    <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}}>
      {Array.from({length: n}).map((_, i) => {
        const x0 = (i * 137.5) % W;
        const sp = 20 + (i % 7) * 3;
        const y = (((i * 91) % H) + f * sp) % (H + 120) - 60;
        const x = x0 - y * 0.18;
        return <line key={i} x1={x} y1={y} x2={x - 6} y2={y + 26} stroke="rgba(230,242,252,0.55)" strokeWidth={2} strokeLinecap="round" />;
      })}
      <rect x={0} y={0} width={W} height={H} fill={`rgba(40,55,75,${0.12 * intensity})`} />
    </svg>
  );
};
