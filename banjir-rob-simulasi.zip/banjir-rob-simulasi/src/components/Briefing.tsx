import React from 'react';
import {C, FONT, OUTLINE, SHADOW} from '../assets/theme';
import {InteriorBackdrop} from './Backdrops';
import {TeamRow} from './Characters';
import {Icon, IconName} from './Icons';
import {SceneShell, Stage} from './SceneShell';

/** Tata letak briefing: interior posko, tim di kiri, banner fase di kiri-atas; panel di kanan = children. */
export const Briefing: React.FC<{phase: string; sub: string; icon: IconName; color: string; children: React.ReactNode}> = ({phase, sub, icon, color, children}) => (
  <SceneShell>
    <Stage>
      <InteriorBackdrop />
      <TeamRow x0={150} gap={220} y={905} scale={0.9} />
    </Stage>
    <div
      style={{
        position: 'absolute',
        left: 60,
        top: 130,
        width: 840,
        height: 200,
        background: color,
        border: `${OUTLINE}px solid ${C.ink}`,
        borderRadius: 26,
        boxShadow: SHADOW,
        display: 'flex',
        alignItems: 'center',
        gap: 28,
        padding: '0 36px',
        boxSizing: 'border-box',
        fontFamily: FONT,
        color: '#fff',
      }}
    >
      <Icon name={icon} size={110} bg="#fff" color={color} />
      <div>
        <div style={{fontSize: 70, fontWeight: 800, lineHeight: 1.05}}>{phase}</div>
        <div style={{fontSize: 28, fontWeight: 600, marginTop: 6}}>{sub}</div>
      </div>
    </div>
    {children}
  </SceneShell>
);

/** Diagram koordinasi: hub tim dengan 4 simpul pihak terkait. */
export const CoordDiagram: React.FC<{k: number; f: number}> = ({k, f}) => {
  const nodes: {x: number; y: number; label: string; icon: IconName; color: string}[] = [
    {x: 8, y: 14, label: 'Pemerintah desa', icon: 'home', color: '#f6d9a8'},
    {x: 584, y: 14, label: 'Puskesmas', icon: 'hospital', color: '#f5c2c0'},
    {x: 8, y: 400, label: 'Kader kesehatan', icon: 'people', color: '#d7e8c4'},
    {x: 584, y: 400, label: 'Relawan', icon: 'shield', color: '#cfe3f3'},
  ];
  return (
    <svg width={840} height={540} viewBox="0 0 840 540" style={{display: 'block', marginTop: -8}}>
      {nodes.map((n, i) => (
        <path key={`l${i}`} d={`M420 255 L${n.x + 124} ${n.y + 48}`} stroke={C.ink} strokeWidth={5} strokeDasharray="14 10" strokeDashoffset={-f * 1.4} opacity={Math.min(1, k * 4 - i * 0.4)} fill="none" />
      ))}
      <g opacity={Math.min(1, k * 3)}>
        <rect x={280} y={205} width={280} height={100} rx={24} fill={C.orange} stroke={C.ink} strokeWidth={4} />
        <text x={420} y={248} textAnchor="middle" fontSize={26} fontWeight={800} fill="#fff" fontFamily={FONT}>Tim Respons</text>
        <text x={420} y={280} textAnchor="middle" fontSize={24} fontWeight={700} fill="#fff" fontFamily={FONT}>Kesehatan Masyarakat</text>
      </g>
      {nodes.map((n, i) => (
        <g key={n.label} opacity={Math.min(1, Math.max(0, k * 4 - i * 0.5))} transform={`translate(${n.x},${n.y})`}>
          <rect width={248} height={96} rx={22} fill={n.color} stroke={C.ink} strokeWidth={4} />
          <g transform="translate(14,22)"><Icon name={n.icon} size={52} /></g>
          <text x={86} y={58} fontSize={26} fontWeight={800} fill={C.ink} fontFamily={FONT}>{n.label}</text>
        </g>
      ))}
      <text x={420} y={520} textAnchor="middle" fontSize={24} fontWeight={700} fill={C.gray} fontFamily={FONT} opacity={Math.min(1, k * 2)}>
        + pihak terkait lainnya
      </text>
    </svg>
  );
};
