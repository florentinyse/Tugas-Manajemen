import React from 'react';
import {useCurrentFrame} from 'remotion';
import {FONT} from '../assets/theme';
import {TEAM, TeamName} from '../config/characters';
import {clamp01} from '../lib/anim';
import {Subtitle as Sub} from '../lib/timing';

const colorOf = (speaker: string): string | null => {
  if (speaker in TEAM) return TEAM[speaker as TeamName].accent === '#2f6f96' ? '#8fd0ff' : TEAM[speaker as TeamName].accent;
  if (speaker === 'Kader') return '#6fe0d2';
  if (speaker === 'Warga') return '#ffd98a';
  return null;
};

/** Subtitle bahasa Indonesia maks. 2 baris, di bawah layar dengan latar semi-transparan. */
export const SubtitleLayer: React.FC<{subtitles: Sub[]}> = ({subtitles}) => {
  const f = useCurrentFrame();
  const cur = subtitles.find((s) => f >= s.startFrame && f < s.endFrame);
  if (!cur) return null;
  const op = Math.min(clamp01((f - cur.startFrame) / 5), clamp01((cur.endFrame - f) / 4));
  const col = colorOf(cur.speaker);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 34, display: 'flex', justifyContent: 'center', opacity: op, pointerEvents: 'none'}}>
      <div
        style={{
          maxWidth: 1560,
          padding: '14px 32px',
          background: 'rgba(14,18,28,0.78)',
          borderRadius: 18,
          color: '#fff',
          fontFamily: FONT,
          fontSize: 40,
          fontWeight: 600,
          lineHeight: 1.28,
          textAlign: 'center',
          textShadow: '0 2px 4px rgba(0,0,0,0.5)',
        }}
      >
        {col ? <span style={{color: col, fontWeight: 800}}>{cur.speaker}: </span> : null}
        {cur.text}
      </div>
    </div>
  );
};
