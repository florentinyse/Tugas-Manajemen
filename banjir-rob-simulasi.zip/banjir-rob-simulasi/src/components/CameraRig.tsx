import React from 'react';
import {AbsoluteFill, Easing, interpolate} from 'remotion';
import {H, W} from '../assets/theme';
import {useCue} from '../lib/timing';

export type CamKey = {at?: number; line?: number; cx: number; cy: number; s: number};

/**
 * Kamera 2D: pan & zoom halus antar keyframe. Keyframe dapat dipasang di posisi
 * progres adegan (at: 0..1) atau di awal kalimat tertentu (line: indeks kalimat).
 */
export const CameraRig: React.FC<{keys: CamKey[]; worldW: number; children: React.ReactNode}> = ({keys, worldW, children}) => {
  const cue = useCue();
  const times: number[] = [];
  keys.forEach((k, i) => {
    const raw = k.at ?? (k.line !== undefined ? cue.mark(k.line) : 0);
    times.push(i === 0 ? 0 : Math.max(raw, times[i - 1] + 0.001));
  });
  const opts = {
    extrapolateLeft: 'clamp' as const,
    extrapolateRight: 'clamp' as const,
    easing: Easing.inOut(Easing.cubic),
  };
  const val = (pick: (k: CamKey) => number): number =>
    keys.length === 1 ? pick(keys[0]) : interpolate(cue.p, times, keys.map(pick), opts);
  const cx = val((k) => k.cx) + Math.sin(cue.f / 90) * 5;
  const cy = val((k) => k.cy) + Math.cos(cue.f / 110) * 3;
  const s = val((k) => k.s);
  return (
    <AbsoluteFill style={{overflow: 'hidden'}}>
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: worldW,
          height: H,
          transformOrigin: '0 0',
          transform: `translate(${W / 2 - cx * s}px, ${H / 2 - cy * s}px) scale(${s})`,
        }}
      >
        <svg width={worldW} height={H} viewBox={`0 0 ${worldW} ${H}`} style={{display: 'block'}}>
          {children}
        </svg>
      </div>
    </AbsoluteFill>
  );
};
