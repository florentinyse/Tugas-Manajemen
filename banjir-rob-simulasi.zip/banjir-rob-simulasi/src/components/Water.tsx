import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../assets/theme';

/** Air banjir cokelat keruh: permukaan bergelombang, kilau bergerak, sampah hanyut. */
export const FloodWater: React.FC<{
  width: number;
  top: number;
  bottom?: number;
  debris?: boolean;
  opacity?: number;
}> = ({width, top, bottom = 1080, debris = false, opacity = 0.9}) => {
  const f = useCurrentFrame();
  const pts: string[] = [];
  for (let px = 0; px <= width; px += 24) {
    const y = top + Math.sin(px * 0.018 + f * 0.07) * 5 + Math.sin(px * 0.007 - f * 0.03) * 4;
    pts.push(`${px},${y.toFixed(1)}`);
  }
  const d = `M0,${bottom} L${pts.join(' L')} L${width},${bottom} Z`;
  return (
    <g>
      <defs>
        <linearGradient id="floodG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={C.floodLight} />
          <stop offset="1" stopColor={C.floodDark} />
        </linearGradient>
      </defs>
      <path d={d} fill="url(#floodG)" opacity={opacity} />
      <path d={`M${pts.join(' L')}`} fill="none" stroke={C.ink} strokeWidth={3} opacity={0.5} />
      {Array.from({length: 16}).map((_, i) => {
        const x = (i * 173 + f * (0.8 + (i % 3) * 0.5)) % width;
        const y = top + 26 + ((i * 37) % 150);
        return <path key={i} d={`M${x} ${y} h${50 + (i % 4) * 22}`} stroke="rgba(255,235,200,0.28)" strokeWidth={4} strokeLinecap="round" />;
      })}
      {debris
        ? Array.from({length: 7}).map((_, i) => {
            const x = (i * 410 + f * 0.7) % width;
            const y = top + 8 + Math.sin(f * 0.06 + i) * 4;
            const kind = i % 3;
            return (
              <g key={i} transform={`translate(${x},${y}) rotate(${Math.sin(f * 0.04 + i) * 8})`}>
                {kind === 0 ? <rect x={-16} y={-8} width={32} height={14} rx={2} fill={C.woodLight} stroke={C.ink} strokeWidth={2.5} /> : null}
                {kind === 1 ? <ellipse cx={0} cy={-2} rx={14} ry={6} fill="#e8eef2" stroke={C.ink} strokeWidth={2.5} /> : null}
                {kind === 2 ? <rect x={-5} y={-14} width={10} height={20} rx={3} fill="#7db4d6" stroke={C.ink} strokeWidth={2.5} /> : null}
              </g>
            );
          })
        : null}
    </g>
  );
};

export const River: React.FC<{x: number; y: number; w: number; h: number}> = ({x, y, w, h}) => {
  const f = useCurrentFrame();
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} fill="#5f9cbc" />
      <rect x={x} y={y} width={w} height={8} fill="#4a86a6" />
      {Array.from({length: Math.floor(w / 140)}).map((_, i) => {
        const px = x + ((i * 140 + f * 0.6) % w);
        const py = y + 22 + ((i * 29) % (h - 30));
        return <path key={i} d={`M${px} ${py} q14 -6 28 0 t28 0`} fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth={3} strokeLinecap="round" />;
      })}
    </g>
  );
};

const Reed: React.FC<{x: number; y: number; h: number; sway: number}> = ({x, y, h, sway}) => (
  <g transform={`translate(${x},${y}) rotate(${sway})`}>
    <path d={`M0 0 Q-8 ${-h * 0.6} -16 ${-h}`} stroke="#3f7a4b" strokeWidth={4} fill="none" strokeLinecap="round" />
    <path d={`M0 0 Q2 ${-h * 0.6} 4 ${-h - 10}`} stroke="#4f9a62" strokeWidth={4} fill="none" strokeLinecap="round" />
    <path d={`M0 0 Q10 ${-h * 0.5} 18 ${-h + 6}`} stroke="#3f7a4b" strokeWidth={4} fill="none" strokeLinecap="round" />
    <rect x={2} y={-h - 26} width={7} height={24} rx={3} fill="#7a4a2a" />
  </g>
);

/** Rawa: genangan air tenang dengan rumput rawa dan daun teratai. */
export const Swamp: React.FC<{x: number; y: number; w: number; h: number}> = ({x, y, w, h}) => {
  const f = useCurrentFrame();
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} fill="#6f9a7a" />
      <rect x={x} y={y} width={w} height={10} fill="#58846a" />
      {Array.from({length: Math.floor(w / 90)}).map((_, i) => (
        <ellipse key={`p${i}`} cx={x + 40 + i * 90 + ((i * 37) % 30)} cy={y + 40 + ((i * 53) % (h - 60))} rx={20} ry={7} fill="#4f9a62" opacity={0.9} />
      ))}
      {Array.from({length: Math.floor(w / 70)}).map((_, i) => (
        <Reed key={`r${i}`} x={x + 20 + i * 70 + ((i * 23) % 25)} y={y + 30 + ((i * 41) % (h - 40))} h={50 + ((i * 17) % 30)} sway={Math.sin(f * 0.04 + i) * 3} />
      ))}
    </g>
  );
};
