import React from 'react';
import {C} from '../assets/theme';

export type IconName =
  | 'droplet' | 'well' | 'cross' | 'skin' | 'mosquito' | 'bottle' | 'people' | 'pin' | 'box'
  | 'clipboard' | 'thermo' | 'soap' | 'toilet' | 'radio' | 'hospital' | 'check' | 'warn' | 'link'
  | 'shield' | 'chart' | 'clock' | 'home' | 'route' | 'eye' | 'rain';

export const Icon: React.FC<{name: IconName; size?: number; color?: string; bg?: string}> = ({
  name,
  size = 44,
  color = C.blue,
  bg,
}) => {
  const s = {stroke: C.ink, strokeWidth: 2.6, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};
  const bodies: Record<IconName, React.ReactElement> = {
    droplet: <path d="M24 5 C24 5 11 21 11 30 A13 13 0 0 0 37 30 C37 21 24 5 24 5 Z" fill={color} {...s} />,
    well: (
      <g {...s}>
        <rect x={10} y={28} width={28} height={14} fill="#b98a5a" />
        <ellipse cx={24} cy={28} rx={14} ry={5} fill="#7a5a3a" />
        <path d="M12 28 V13 M36 28 V13" fill="none" />
        <path d="M8 15 L24 5 L40 15 Z" fill={C.red} />
      </g>
    ),
    cross: (
      <g {...s}>
        <rect x={8} y={8} width={32} height={32} rx={8} fill="#fff" />
        <path d="M24 14 V34 M14 24 H34" stroke={color} strokeWidth={6} />
      </g>
    ),
    skin: (
      <g {...s}>
        <circle cx={24} cy={24} r={16} fill="#f0c29b" />
        {[[18, 20], [28, 17], [24, 28], [32, 27], [17, 30]].map(([cx, cy]) => (
          <circle key={`${cx}-${cy}`} cx={cx} cy={cy} r={2.6} fill={C.red} stroke="none" />
        ))}
      </g>
    ),
    mosquito: (
      <g {...s}>
        <ellipse cx={20} cy={14} rx={8} ry={4} fill="#e8f4fb" transform="rotate(-30 20 14)" />
        <ellipse cx={26} cy={12} rx={8} ry={4} fill="#e8f4fb" transform="rotate(-10 26 12)" />
        <ellipse cx={22} cy={27} rx={12} ry={5.5} fill={color} />
        <circle cx={35} cy={24} r={4.5} fill={color} />
        <path d="M39 25 L46 31" fill="none" />
        <path d="M14 31 L10 40 M22 32 L22 42 M29 31 L33 40" fill="none" />
      </g>
    ),
    bottle: (
      <g {...s}>
        <path d="M20 7 H28 V13 L33 19 V42 H15 V19 L20 13 Z" fill={color} />
        <rect x={19} y={4} width={10} height={5} fill="#fff" />
        <path d="M15 28 H33" fill="none" stroke="#fff" />
      </g>
    ),
    people: (
      <g {...s}>
        <circle cx={14} cy={17} r={5} fill="#f0c29b" />
        <circle cx={34} cy={17} r={5} fill="#d9a273" />
        <path d="M6 38 Q6 27 14 27 Q20 27 22 32 L26 32 Q28 27 34 27 Q42 27 42 38 Z" fill={color} />
        <circle cx={24} cy={13} r={6.5} fill="#e8b88f" />
        <path d="M13 42 Q13 28 24 28 Q35 28 35 42 Z" fill={color} />
      </g>
    ),
    pin: (
      <g {...s}>
        <path d="M24 4 C15 4 9 10 9 18 C9 29 24 44 24 44 C24 44 39 29 39 18 C39 10 33 4 24 4 Z" fill={color} />
        <circle cx={24} cy={18} r={6} fill="#fff" />
      </g>
    ),
    box: (
      <g {...s}>
        <path d="M24 6 L42 14 V34 L24 42 L6 34 V14 Z" fill={C.woodLight} />
        <path d="M6 14 L24 22 L42 14 M24 22 V42" fill="none" />
      </g>
    ),
    clipboard: (
      <g {...s}>
        <rect x={10} y={8} width={28} height={34} rx={4} fill="#fff" />
        <rect x={17} y={4} width={14} height={8} rx={2} fill={color} />
        <path d="M16 20 H32 M16 27 H32 M16 34 H27" fill="none" />
      </g>
    ),
    thermo: (
      <g {...s}>
        <rect x={19} y={5} width={10} height={28} rx={5} fill="#fff" />
        <circle cx={24} cy={36} r={7.5} fill={C.red} />
        <rect x={22.6} y={16} width={2.8} height={20} fill={C.red} stroke="none" />
      </g>
    ),
    soap: (
      <g {...s}>
        <rect x={9} y={25} width={30} height={16} rx={6} fill={color} />
        <circle cx={16} cy={16} r={5} fill="#dff3ff" />
        <circle cx={28} cy={11} r={4} fill="#dff3ff" />
        <circle cx={35} cy={19} r={3} fill="#dff3ff" />
      </g>
    ),
    toilet: (
      <g {...s}>
        <rect x={14} y={5} width={20} height={13} rx={3} fill="#fff" />
        <path d="M9 20 H39 Q39 34 24 37 Q9 34 9 20 Z" fill={color} />
        <rect x={17} y={37} width={14} height={6} fill="#fff" />
      </g>
    ),
    radio: (
      <g {...s}>
        <rect x={10} y={16} width={24} height={28} rx={5} fill={color} />
        <path d="M30 16 L37 4" fill="none" />
        <circle cx={22} cy={31} r={6} fill="#fff" />
      </g>
    ),
    hospital: (
      <g {...s}>
        <rect x={6} y={10} width={36} height={32} rx={4} fill="#fff" />
        <path d="M24 17 V35 M15 26 H33" stroke={C.red} strokeWidth={6} />
      </g>
    ),
    check: (
      <g {...s}>
        <circle cx={24} cy={24} r={19} fill={C.green} />
        <path d="M14 25 L21 32 L35 17" fill="none" stroke="#fff" strokeWidth={5} />
      </g>
    ),
    warn: (
      <g {...s}>
        <path d="M24 5 L44 40 H4 Z" fill={C.mustard} />
        <path d="M24 17 V28" fill="none" strokeWidth={4} />
        <circle cx={24} cy={34} r={2.2} fill={C.ink} />
      </g>
    ),
    link: (
      <g {...s}>
        <path d="M24 12 L11 35 M24 12 L37 35 M11 35 H37" fill="none" />
        <circle cx={24} cy={11} r={7} fill={color} />
        <circle cx={11} cy={35} r={7} fill={color} />
        <circle cx={37} cy={35} r={7} fill={color} />
      </g>
    ),
    shield: (
      <g {...s}>
        <path d="M24 5 L40 11 V24 C40 33 33 40 24 44 C15 40 8 33 8 24 V11 Z" fill={color} />
        <path d="M16 24 L22 30 L33 17" fill="none" stroke="#fff" strokeWidth={4} />
      </g>
    ),
    chart: (
      <g {...s}>
        <rect x={9} y={26} width={9} height={14} fill={color} />
        <rect x={20} y={15} width={9} height={25} fill={C.mustard} />
        <rect x={31} y={8} width={9} height={32} fill={C.green} />
      </g>
    ),
    clock: (
      <g {...s}>
        <circle cx={24} cy={24} r={18} fill="#fff" />
        <path d="M24 13 V25 L32 29" fill="none" strokeWidth={3.5} />
      </g>
    ),
    home: (
      <g {...s}>
        <path d="M6 22 L24 7 L42 22 Z" fill={C.red} />
        <rect x={11} y={22} width={26} height={18} fill={C.woodLight} />
        <rect x={20} y={28} width={8} height={12} fill={C.woodDark} />
      </g>
    ),
    route: (
      <g {...s}>
        <path d="M8 38 C8 22 22 30 24 20 C26 10 38 14 40 10" fill="none" strokeDasharray="4 5" strokeWidth={3.5} />
        <path d="M34 6 L41 10 L35 16" fill="none" strokeWidth={3.5} />
      </g>
    ),
    eye: (
      <g {...s}>
        <path d="M4 24 Q24 6 44 24 Q24 42 4 24 Z" fill="#fff" />
        <circle cx={24} cy={24} r={7} fill={color} />
        <circle cx={24} cy={24} r={3} fill={C.ink} />
      </g>
    ),
    rain: (
      <g {...s}>
        <path d="M12 26 Q6 26 6 20 Q6 14 13 14 Q16 7 24 8 Q33 8 35 16 Q42 16 42 22 Q42 27 36 27 Z" fill="#c9d5df" />
        <path d="M14 33 L11 42 M24 33 L21 42 M34 33 L31 42" fill="none" stroke={C.blueDeep} strokeWidth={3.5} />
      </g>
    ),
  };
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" style={{flexShrink: 0}}>
      {bg ? <circle cx={24} cy={24} r={23.5} fill={bg} stroke={C.ink} strokeWidth={2.4} /> : null}
      <g transform={bg ? 'translate(4.8,4.8) scale(0.8)' : undefined}>{bodies[name]}</g>
    </svg>
  );
};
