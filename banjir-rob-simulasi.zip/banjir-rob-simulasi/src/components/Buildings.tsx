import React from 'react';
import {C, FONT} from '../assets/theme';

const st = {stroke: C.ink, strokeWidth: 4, strokeLinejoin: 'round' as const};

/** Rumah panggung. (x,y) = tengah-bawah tiang. */
export const StiltHouse: React.FC<{
  x: number;
  y: number;
  w?: number;
  wall?: string;
  roof?: string;
  stilt?: number;
  scale?: number;
  flip?: boolean;
}> = ({x, y, w = 250, wall = C.woodLight, roof = C.teal, stilt = 100, scale = 1, flip = false}) => {
  const h = 120;
  const floorY = -stilt;
  const wallTop = floorY - h;
  return (
    <g transform={`translate(${x},${y}) scale(${(flip ? -1 : 1) * scale},${scale})`}>
      {[-w / 2 + 16, -w / 6, w / 6, w / 2 - 16].map((sx) => (
        <rect key={sx} x={sx - 7} y={floorY} width={14} height={stilt + 8} fill={C.woodDark} {...st} />
      ))}
      <path d={`M${-w / 2 - 6} ${floorY} L${-w / 2 - 64} 6 L${-w / 2 - 42} 6 L${-w / 2 + 12} ${floorY} Z`} fill={C.wood} {...st} />
      <rect x={-w / 2 - 10} y={floorY - 14} width={w + 20} height={16} fill={C.wood} {...st} />
      <rect x={-w / 2} y={wallTop} width={w} height={h - 14} fill={wall} {...st} />
      {Array.from({length: Math.floor(w / 24)}).map((_, i) => (
        <path key={i} d={`M${-w / 2 + 24 * (i + 1)} ${wallTop + 3} V${wallTop + h - 17}`} stroke="rgba(34,32,43,0.28)" strokeWidth={2} />
      ))}
      <rect x={-w / 2 + 24} y={wallTop + 26} width={46} height={h - 40} fill={C.woodDark} {...st} />
      <rect x={w / 2 - 92} y={wallTop + 28} width={60} height={46} fill="#cfe6f2" {...st} />
      <path d={`M${w / 2 - 62} ${wallTop + 28} V${wallTop + 74} M${w / 2 - 92} ${wallTop + 51} H${w / 2 - 32}`} stroke={C.ink} strokeWidth={3} />
      <path d={`M${-w / 2 - 30} ${wallTop} L0 ${wallTop - 82} L${w / 2 + 30} ${wallTop} Z`} fill={roof} {...st} />
      <path d={`M${-w / 2 - 16} ${wallTop - 14} L${w / 2 + 16} ${wallTop - 14}`} stroke="rgba(0,0,0,0.25)" strokeWidth={3} />
    </g>
  );
};

/** Balai warga tampak depan, terbuka, dengan siluet pengungsi. */
export const BalaiWarga: React.FC<{x: number; y: number; w?: number; crowd?: number}> = ({x, y, w = 560, crowd = 0}) => {
  const raise = 70;
  const wallH = 150;
  const fy = -raise;
  const cols = [-w / 2 + 24, -w / 6, w / 6, w / 2 - 24];
  const hues = ['#e9c46a', '#6aa0a8', '#c85a4a', '#7a8cc0', '#f2a7b5', '#8d9a86'];
  return (
    <g transform={`translate(${x},${y})`}>
      {[-w / 2 + 30, 0, w / 2 - 30].map((px) => (
        <rect key={px} x={px - 8} y={fy} width={16} height={raise + 8} fill={C.woodDark} {...st} />
      ))}
      <rect x={-w / 2} y={fy - 14} width={w} height={16} fill={C.wood} {...st} />
      <rect x={-w / 2 + 10} y={fy - wallH} width={w - 20} height={wallH - 14} fill="#6b4a2f" {...st} />
      {Array.from({length: crowd}).map((_, i) => {
        const px = -w / 2 + 50 + ((i * 41) % (w - 100));
        const row = i % 2;
        const py = fy - 16 - row * 16;
        return (
          <g key={i}>
            <rect x={px - 13} y={py - 40} width={26} height={30} rx={8} fill={hues[i % hues.length]} stroke={C.ink} strokeWidth={2.5} />
            <circle cx={px} cy={py - 52} r={12} fill={i % 3 === 0 ? C.skinB : C.skinA} stroke={C.ink} strokeWidth={2.5} />
          </g>
        );
      })}
      {cols.map((cx) => (
        <rect key={cx} x={cx - 8} y={fy - wallH} width={16} height={wallH - 12} fill={C.woodLight} {...st} />
      ))}
      <path d={`M${-w / 2 - 44} ${fy - wallH} L${-w / 2 + 60} ${fy - wallH - 96} L${w / 2 - 60} ${fy - wallH - 96} L${w / 2 + 44} ${fy - wallH} Z`} fill="#a8452f" {...st} />
      <path d={`M${-w / 2 - 20} ${fy - wallH - 28} L${w / 2 + 20} ${fy - wallH - 28}`} stroke="rgba(0,0,0,0.25)" strokeWidth={3} />
      <rect x={-125} y={fy - wallH - 62} width={250} height={42} rx={6} fill={C.teal} {...st} />
      <text x={0} y={fy - wallH - 33} textAnchor="middle" fontSize={26} fontWeight={800} fill="#fff" fontFamily={FONT}>
        BALAI WARGA
      </text>
      {[0, 1, 2].map((k) => (
        <rect key={k} x={-70 - k * 10} y={fy - 14 + k * 26} width={140 + k * 20} height={26} fill={C.woodLight} {...st} />
      ))}
    </g>
  );
};

export const Sumur: React.FC<{x: number; y: number; flagged?: number}> = ({x, y, flagged = 0}) => (
  <g transform={`translate(${x},${y})`}>
    <path d="M-38 0 L-38 -58 M38 0 L38 -58" stroke={C.ink} strokeWidth={9} />
    <path d="M-38 0 L-38 -58 M38 0 L38 -58" stroke={C.woodLight} strokeWidth={4} />
    <path d="M-54 -56 L0 -92 L54 -56 Z" fill={C.red} {...st} />
    <rect x={-42} y={-24} width={84} height={26} rx={4} fill="#b98a5a" {...st} />
    <ellipse cx={0} cy={-24} rx={42} ry={10} fill={C.flood} {...st} />
    <path d="M0 -76 V-40" stroke={C.ink} strokeWidth={3} />
    <rect x={-8} y={-42} width={16} height={14} fill={C.woodDark} {...st} strokeWidth={3} />
    {flagged > 0.01 ? (
      <g opacity={flagged}>
        <path d="M-60 -20 L60 -44" stroke="#f2d23c" strokeWidth={8} />
        <path d="M-60 -20 L60 -44" stroke={C.ink} strokeWidth={2} strokeDasharray="8 8" />
        <rect x={-62} y={-132} width={124} height={34} rx={6} fill={C.red} {...st} strokeWidth={3} />
        <text x={0} y={-109} textAnchor="middle" fontSize={15} fontWeight={800} fill="#fff" fontFamily={FONT}>
          JANGAN DIMINUM
        </text>
      </g>
    ) : null}
  </g>
);

export const Jembatan: React.FC<{x: number; y: number; w: number}> = ({x, y, w}) => (
  <g transform={`translate(${x},${y})`}>
    {Array.from({length: Math.floor(w / 80) + 1}).map((_, i) => (
      <rect key={`p${i}`} x={i * 80 - 6} y={0} width={12} height={58} fill={C.woodDark} {...st} strokeWidth={3} />
    ))}
    <rect x={0} y={-16} width={w} height={18} fill={C.woodLight} {...st} />
    <rect x={0} y={-52} width={w} height={8} fill={C.wood} {...st} strokeWidth={3} />
    {Array.from({length: Math.floor(w / 80) + 1}).map((_, i) => (
      <rect key={`b${i}`} x={i * 80 - 4} y={-52} width={8} height={36} fill={C.wood} {...st} strokeWidth={3} />
    ))}
  </g>
);

export const Titian: React.FC<{x: number; y: number; w: number}> = ({x, y, w}) => (
  <g transform={`translate(${x},${y})`}>
    {Array.from({length: Math.floor(w / 200) + 1}).map((_, i) => (
      <rect key={i} x={i * 200 - 8} y={20} width={16} height={74} fill={C.woodDark} {...st} />
    ))}
    <rect x={0} y={0} width={w} height={24} fill={C.woodLight} {...st} />
    {Array.from({length: Math.floor(w / 60)}).map((_, i) => (
      <path key={i} d={`M${(i + 1) * 60} 2 V22`} stroke="rgba(34,32,43,0.45)" strokeWidth={2.5} />
    ))}
  </g>
);

export const Jukung: React.FC<{x: number; y: number; flip?: boolean; scale?: number; children?: React.ReactNode}> = ({
  x,
  y,
  flip = false,
  scale = 1,
  children,
}) => (
  <g transform={`translate(${x},${y}) scale(${(flip ? -1 : 1) * scale},${scale})`}>
    {children}
    <path d="M-110 -22 Q-124 -34 -118 -44 L118 -44 Q128 -30 112 -20 Q0 14 -110 -22 Z" fill={C.wood} {...st} />
    <path d="M-100 -34 L104 -34" stroke={C.mustard} strokeWidth={6} />
  </g>
);

export const BoxStack: React.FC<{x: number; y: number; n?: number}> = ({x, y, n = 3}) => (
  <g transform={`translate(${x},${y})`}>
    {Array.from({length: n}).map((_, i) => {
      const row = Math.floor(i / 2);
      const col = i % 2;
      return (
        <g key={i} transform={`translate(${col * 68 - (row ? -34 : 0)},${-row * 52})`}>
          <rect x={-32} y={-52} width={64} height={52} rx={3} fill={C.woodLight} {...st} strokeWidth={3.5} />
          <path d="M-32 -30 H32 M0 -52 V-30" stroke={C.ink} strokeWidth={3} />
        </g>
      );
    })}
    <rect x={-22} y={-132} width={22} height={46} rx={8} fill="#dff0fa" stroke={C.ink} strokeWidth={3} opacity={0} />
  </g>
);

export const WaterCrate: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x},${y})`}>
    <rect x={-44} y={-40} width={88} height={40} rx={4} fill="#3a7bb0" {...st} strokeWidth={3.5} />
    {[-28, -10, 8, 26].map((bx) => (
      <g key={bx}>
        <rect x={bx - 7} y={-72} width={14} height={34} rx={5} fill="#dff0fa" stroke={C.ink} strokeWidth={2.5} />
        <rect x={bx - 4} y={-78} width={8} height={7} fill={C.blueDeep} stroke={C.ink} strokeWidth={2} />
      </g>
    ))}
  </g>
);

export const HandwashStation: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x},${y})`}>
    <path d="M-34 0 L-26 -96 M34 0 L26 -96" stroke={C.ink} strokeWidth={10} strokeLinecap="round" />
    <path d="M-34 0 L-26 -96 M34 0 L26 -96" stroke={C.woodLight} strokeWidth={5} strokeLinecap="round" />
    <rect x={-44} y={-110} width={88} height={16} rx={3} fill={C.wood} {...st} strokeWidth={3.5} />
    <path d="M-30 -112 H18 L30 -102 V-170 Q30 -178 22 -178 H-22 Q-30 -178 -30 -170 Z" fill={C.blue} {...st} strokeWidth={3.5} />
    <rect x={-10} y={-190} width={18} height={14} rx={3} fill="#fff" {...st} strokeWidth={3} />
    <path d="M30 -132 H46 V-122" fill="none" stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
    <ellipse cx={-4} cy={-22} rx={34} ry={9} fill="#dff0fa" {...st} strokeWidth={3} />
    <rect x={-50} y={-124} width={22} height={12} rx={5} fill="#f6f2ff" stroke={C.ink} strokeWidth={2.5} />
  </g>
);

export const Latrine: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x},${y})`}>
    <rect x={-38} y={-150} width={76} height={150} fill="#4a8fc0" {...st} />
    <rect x={-24} y={-130} width={48} height={118} fill="#3a7bb0" {...st} strokeWidth={3} />
    <path d="M-46 -150 L0 -176 L46 -150 Z" fill="#2f6f96" {...st} />
    <circle cx={14} cy={-70} r={4} fill="#fff" />
    <rect x={44} y={-48} width={34} height={48} rx={5} fill="#5b6672" {...st} strokeWidth={3.5} />
    <rect x={40} y={-54} width={42} height={10} rx={3} fill="#444b57" {...st} strokeWidth={3} />
  </g>
);

export const DeskTable: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x},${y})`}>
    <path d="M-60 -50 V0 M60 -50 V0" stroke={C.ink} strokeWidth={10} strokeLinecap="round" />
    <path d="M-60 -50 V0 M60 -50 V0" stroke={C.woodDark} strokeWidth={5} strokeLinecap="round" />
    <rect x={-76} y={-64} width={152} height={16} rx={3} fill={C.woodLight} {...st} strokeWidth={3.5} />
    <rect x={-56} y={-80} width={42} height={16} fill="#fff" stroke={C.ink} strokeWidth={2.5} />
    <rect x={-8} y={-76} width={34} height={12} fill="#fff" stroke={C.ink} strokeWidth={2.5} />
    <rect x={36} y={-92} width={22} height={28} rx={3} fill={C.red} stroke={C.ink} strokeWidth={2.5} />
  </g>
);
