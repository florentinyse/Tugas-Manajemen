import React from 'react';
import {Audio, Sequence, staticFile} from 'remotion';
import {AUDIO} from '../config/audio';
import {clamp01} from '../lib/anim';
import {AudioManifest, Timing} from '../lib/timing';

const fade = (f: number, total: number, fps: number, inSec: number, outSec: number): number =>
  Math.min(clamp01(f / Math.max(1, inSec * fps)), clamp01((total - f) / Math.max(1, outSec * fps)));

/**
 * Seluruh audio: narasi (file lokal), musik latar, ambience (hujan/air/keramaian), SFX lembut.
 * Narasi dimuat dari public/audio-manifest.json (dibuat oleh `npm run prepare:audio`).
 */
export const AudioTracks: React.FC<{timing: Timing; manifest: AudioManifest}> = ({timing, manifest}) => {
  const {fps, totalFrames} = timing;
  const A = AUDIO;
  return (
    <>
      {A.music.enabled ? (
        <Audio
          src={staticFile(A.music.file)}
          loop
          volume={(f) => A.music.volume * fade(f, totalFrames, fps, A.music.fadeInSec, A.music.fadeOutSec)}
        />
      ) : null}
      {timing.scenes.map((s) => {
        const amb = A.ambience[s.sceneKey] ?? {rain: 0, water: 0, murmur: 0};
        const edge = (f: number) => Math.min(clamp01(f / 20), clamp01((s.durationFrames - f) / 20));
        const first = s.lines[0];
        const narr = manifest.narration[s.id];
        return (
          <React.Fragment key={s.id}>
            <Sequence from={s.startFrame} durationInFrames={s.durationFrames}>
              {amb.rain > 0 ? <Audio src={staticFile(A.files.rain)} loop volume={(f) => A.baseVolume.rain * amb.rain * edge(f)} /> : null}
              {amb.water > 0 ? <Audio src={staticFile(A.files.water)} loop volume={(f) => A.baseVolume.water * amb.water * edge(f)} /> : null}
              {amb.murmur > 0 ? <Audio src={staticFile(A.files.murmur)} loop volume={(f) => A.baseVolume.murmur * amb.murmur * edge(f)} /> : null}
            </Sequence>
            {A.sfx.enabled && A.sfx.swooshOnSceneStart ? (
              <Sequence from={s.startFrame} durationInFrames={45}>
                <Audio src={staticFile(A.files.swoosh)} volume={A.sfx.swooshVolume} />
              </Sequence>
            ) : null}
            {A.sfx.enabled && A.sfx.popOnLinesFor.includes(s.sceneKey)
              ? s.lines.map((l) => (
                  <Sequence key={l.id} from={l.startFrame} durationInFrames={20}>
                    <Audio src={staticFile(A.files.pop)} volume={A.sfx.popVolume} />
                  </Sequence>
                ))
              : null}
            {narr && first ? (
              <Sequence from={first.startFrame} durationInFrames={Math.max(1, s.endFrame - first.startFrame)}>
                <Audio src={staticFile(narr)} volume={A.narrationVolume} />
              </Sequence>
            ) : null}
          </React.Fragment>
        );
      })}
    </>
  );
};
