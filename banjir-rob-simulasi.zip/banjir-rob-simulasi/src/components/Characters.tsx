import React from 'react';
import {Person, Item, Mood, Pose} from './Person';
import {RESIDENTS, ResidentKind, TEAM, TEAM_ORDER, TeamName} from '../config/characters';
import {useSpeaker} from '../lib/timing';

export type CharacterProps = {
  who: TeamName;
  x: number;
  y: number;
  scale?: number;
  flip?: boolean;
  mood?: Mood;
  pose?: Pose;
  item?: Item;
  walk?: boolean;
  showLabel?: boolean;
  opacity?: number;
};

/** Tokoh utama. Otomatis "berbicara" saat namanya menjadi pembicara aktif di timing.json. */
export const Character: React.FC<CharacterProps> = ({
  who,
  x,
  y,
  scale = 0.9,
  flip = false,
  mood,
  pose,
  item,
  walk = false,
  showLabel = true,
  opacity = 1,
}) => {
  const speaker = useSpeaker();
  const m = TEAM[who];
  const speaking = speaker === who;
  const it = item ?? m.item;
  const ps: Pose = pose ?? (it === 'clipboard' ? 'hold' : it === 'box' ? 'carry' : speaking ? 'talk' : 'idle');
  return (
    <Person
      spec={m.spec}
      x={x}
      y={y}
      scale={scale}
      flip={flip}
      mood={mood ?? m.mood}
      pose={ps}
      item={it}
      speaking={speaking}
      walk={walk}
      opacity={opacity}
      glow={speaking ? m.accent : undefined}
      label={showLabel ? m.name : undefined}
      sub={showLabel ? m.short : undefined}
      labelColor={m.accent}
    />
  );
};

export type TeamRowProps = {
  xs?: number[];
  x0?: number;
  gap?: number;
  y: number;
  scale?: number;
  order?: TeamName[];
  moods?: Partial<Record<TeamName, Mood>>;
  poses?: Partial<Record<TeamName, Pose>>;
  items?: Partial<Record<TeamName, Item>>;
  flipFrom?: number;
  showLabel?: boolean;
  opacity?: number;
};

export const TeamRow: React.FC<TeamRowProps> = ({
  xs,
  x0 = 150,
  gap = 220,
  y,
  scale = 0.9,
  order = TEAM_ORDER,
  moods = {},
  poses = {},
  items = {},
  flipFrom,
  showLabel = true,
  opacity = 1,
}) => (
  <g>
    {order.map((n, i) => (
      <Character
        key={n}
        who={n}
        x={xs ? xs[i] : x0 + i * gap}
        y={y}
        scale={scale}
        mood={moods[n]}
        pose={poses[n]}
        item={items[n]}
        flip={flipFrom !== undefined && i >= flipFrom}
        showLabel={showLabel}
        opacity={opacity}
      />
    ))}
  </g>
);

export type ResidentProps = {
  kind: ResidentKind;
  x: number;
  y: number;
  scale?: number;
  flip?: boolean;
  mood?: Mood;
  pose?: Pose;
  item?: Item;
  walk?: boolean;
  /** nama pembicara di timing.json bila tokoh ini ikut berbicara (mis. "Warga", "Kader") */
  speakerName?: string;
  label?: string;
  opacity?: number;
};

export const Resident: React.FC<ResidentProps> = ({
  kind,
  x,
  y,
  scale = 1,
  flip = false,
  mood,
  pose = 'idle',
  item = 'none',
  walk = false,
  speakerName,
  label,
  opacity = 1,
}) => {
  const speaker = useSpeaker();
  const preset = RESIDENTS[kind];
  const speaking = !!speakerName && speaker === speakerName;
  return (
    <Person
      spec={preset.spec}
      x={x}
      y={y}
      scale={scale * preset.scale}
      flip={flip}
      mood={mood ?? preset.mood}
      pose={speaking && pose === 'idle' ? 'talk' : pose}
      item={item}
      speaking={speaking}
      walk={walk}
      opacity={opacity}
      label={label}
      labelColor="#1f8a8a"
    />
  );
};
