import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, FONT} from '../assets/theme';

export type Mood = 'senang' | 'sedih' | 'khawatir' | 'kaget' | 'serius' | 'tekad';
export type Pose = 'idle' | 'hold' | 'point' | 'wave' | 'carry' | 'write' | 'talk' | 'raise';
export type Item = 'none' | 'clipboard' | 'radio' | 'box' | 'bag' | 'jerigen' | 'soap' | 'phone' | 'megaphone';
export type HairStyle = 'ponytail' | 'bob' | 'braid' | 'hijab' | 'short' | 'elder' | 'curly' | 'bun';

export type PersonSpec = {
  skin: string;
  hair: string;
  hairStyle: HairStyle;
  hijab?: string;
  top: string;
  vest?: string;
  vestLabel?: string;
  pants: string;
  boots: string;
  glasses?: boolean;
  mask?: boolean;
  hat?: string;
  peci?: boolean;
  gloves?: string;
  belly?: boolean;
  cane?: boolean;
  bigHead?: boolean;
  coat?: boolean;
};

export type PersonProps = {
  spec: PersonSpec;
  x: number;
  y: number;
  scale?: number;
  flip?: boolean;
  mood?: Mood;
  pose?: Pose;
  item?: Item;
  speaking?: boolean;
  walk?: boolean;
  opacity?: number;
  glow?: string;
  label?: string;
  sub?: string;
  labelColor?: string;
};

const INK = C.ink;
type V = [number, number];
const POSES: Record<Pose, {l: V; r: V}> = {
  idle: {l: [-46, -78], r: [46, -78]},
  hold: {l: [-24, -110], r: [26, -122]},
  point: {l: [-46, -80], r: [118, -176]},
  wave: {l: [-46, -80], r: [70, -238]},
  carry: {l: [-30, -104], r: [30, -104]},
  write: {l: [-20, -108], r: [34, -116]},
  talk: {l: [-48, -86], r: [64, -134]},
  raise: {l: [-70, -224], r: [70, -224]},
};

const Arm: React.FC<{sx: number; sy: number; hx: number; hy: number; sleeve: string; hand: string}> = ({
  sx,
  sy,
  hx,
  hy,
  sleeve,
  hand,
}) => {
  const cx = (sx + hx) / 2 + (sx < 0 ? -8 : 8);
  const cy = (sy + hy) / 2 + 16;
  const d = `M${sx} ${sy} Q${cx} ${cy} ${hx} ${hy}`;
  return (
    <g>
      <path d={d} fill="none" stroke={INK} strokeWidth={22} strokeLinecap="round" />
      <path d={d} fill="none" stroke={sleeve} strokeWidth={14} strokeLinecap="round" />
      <circle cx={hx} cy={hy} r={9} fill={hand} stroke={INK} strokeWidth={3} />
    </g>
  );
};

const ItemShape: React.FC<{item: Item; l: V; r: V}> = ({item, l, r}) => {
  switch (item) {
    case 'clipboard': {
      const cx = (l[0] + r[0]) / 2;
      const cy = (l[1] + r[1]) / 2 - 6;
      return (
        <g transform={`translate(${cx},${cy}) rotate(-6)`}>
          <rect x={-24} y={-32} width={48} height={64} rx={5} fill={C.woodLight} stroke={INK} strokeWidth={3} />
          <rect x={-19} y={-24} width={38} height={52} fill="#fff" stroke={INK} strokeWidth={2} />
          <rect x={-10} y={-37} width={20} height={11} rx={3} fill="#8a8f98" stroke={INK} strokeWidth={3} />
          {[-12, -2, 8, 18].map((yy) => (
            <path key={yy} d={`M-13 ${yy} H13`} stroke="#8a8f98" strokeWidth={2.5} />
          ))}
        </g>
      );
    }
    case 'radio':
      return (
        <g transform={`translate(${r[0] + 4},${r[1] - 16})`}>
          <path d="M6 -18 L12 -44" stroke={INK} strokeWidth={4} strokeLinecap="round" />
          <rect x={-10} y={-20} width={22} height={40} rx={6} fill="#33384a" stroke={INK} strokeWidth={3} />
          <rect x={-5} y={-14} width={12} height={10} rx={2} fill="#9fe0c0" />
          <circle cx={1} cy={9} r={4} fill={C.red} />
        </g>
      );
    case 'box':
      return (
        <g transform={`translate(0,${(l[1] + r[1]) / 2 - 8})`}>
          <rect x={-40} y={-28} width={80} height={56} rx={4} fill={C.woodLight} stroke={INK} strokeWidth={3.5} />
          <path d="M-40 -8 H40 M0 -28 V-8" stroke={INK} strokeWidth={3} />
          <rect x={-8} y={-28} width={16} height={20} fill="#e9d9b0" stroke={INK} strokeWidth={2} />
        </g>
      );
    case 'bag':
      return (
        <g>
          <path d="M-34 -146 L22 -84" stroke={INK} strokeWidth={6} strokeLinecap="round" />
          <path d="M-34 -146 L22 -84" stroke="#4a4f5e" strokeWidth={3} strokeLinecap="round" />
          <rect x={-3} y={-110} width={50} height={42} rx={7} fill={C.green} stroke={INK} strokeWidth={3.5} />
          <path d="M22 -104 V-86 M13 -95 H31" stroke="#fff" strokeWidth={5} strokeLinecap="round" />
        </g>
      );
    case 'jerigen':
      return (
        <g transform={`translate(${l[0] - 6},${l[1] + 22})`}>
          <path d="M-18 -30 H10 L18 -22 V26 Q18 30 14 30 H-14 Q-18 30 -18 26 Z" fill={C.blue} stroke={INK} strokeWidth={3.5} />
          <rect x={-6} y={-40} width={14} height={10} rx={3} fill="#fff" stroke={INK} strokeWidth={3} />
          <path d="M-10 -8 H10" stroke="#fff" strokeWidth={3} />
        </g>
      );
    case 'soap':
      return (
        <g transform={`translate(${r[0] + 2},${r[1] - 18})`}>
          <rect x={-10} y={-8} width={20} height={32} rx={6} fill="#f6f2ff" stroke={INK} strokeWidth={3} />
          <rect x={-5} y={-20} width={10} height={12} rx={2} fill={C.violet} stroke={INK} strokeWidth={3} />
          <circle cx={20} cy={-14} r={6} fill="#dff3ff" stroke={INK} strokeWidth={2} />
          <circle cx={26} cy={-28} r={4} fill="#dff3ff" stroke={INK} strokeWidth={2} />
        </g>
      );
    case 'phone':
      return (
        <g transform={`translate(${r[0] + 6},${r[1] - 14}) rotate(12)`}>
          <rect x={-9} y={-16} width={18} height={32} rx={4} fill="#2d3445" stroke={INK} strokeWidth={3} />
          <rect x={-6} y={-12} width={12} height={20} fill="#9fd4ff" />
        </g>
      );
    case 'megaphone':
      return (
        <g transform={`translate(${r[0] + 8},${r[1] - 14}) rotate(-20)`}>
          <path d="M-8 -8 L26 -22 V22 L-8 8 Z" fill={C.mustard} stroke={INK} strokeWidth={3.5} strokeLinejoin="round" />
          <rect x={-18} y={-9} width={12} height={18} rx={4} fill="#444b5e" stroke={INK} strokeWidth={3} />
        </g>
      );
    default:
      return null;
  }
};

const Hair: React.FC<{spec: PersonSpec}> = ({spec}) => {
  const hc = spec.hair;
  const cap = 'M-39 2 C-44 -52 44 -52 39 2 C30 -20 10 -27 -6 -23 C-22 -19 -32 -10 -39 2 Z';
  const st = {stroke: INK, strokeWidth: 3.5, strokeLinejoin: 'round' as const};
  switch (spec.hairStyle) {
    case 'ponytail':
      return (
        <g>
          <path d="M26 -26 Q74 -34 66 22 Q62 44 48 32 Q58 2 30 -6 Z" fill={hc} {...st} />
          <path d={cap} fill={hc} {...st} />
          <rect x={22} y={-26} width={10} height={9} rx={3} fill={C.orange} stroke={INK} strokeWidth={2.5} />
        </g>
      );
    case 'bob':
      return (
        <g>
          <path d={cap} fill={hc} {...st} />
          <path d="M-42 -8 L-42 30 Q-42 40 -32 40 L-26 40 L-30 0 Z" fill={hc} {...st} />
          <path d="M42 -8 L42 30 Q42 40 32 40 L26 40 L30 0 Z" fill={hc} {...st} />
        </g>
      );
    case 'braid':
      return (
        <g>
          <path d={cap} fill={hc} {...st} />
          {[-1, 1].map((s) => (
            <g key={s}>
              <path d={`M${s * 38} 4 Q${s * 52} 30 ${s * 44} 56`} fill="none" stroke={INK} strokeWidth={17} strokeLinecap="round" />
              <path d={`M${s * 38} 4 Q${s * 52} 30 ${s * 44} 56`} fill="none" stroke={hc} strokeWidth={11} strokeLinecap="round" />
              <circle cx={s * 44} cy={58} r={5} fill={C.mustard} stroke={INK} strokeWidth={2} />
            </g>
          ))}
        </g>
      );
    case 'curly':
      return (
        <g>
          {[-34, -22, 22, 34].map((cx, i) => (
            <circle key={cx} cx={cx} cy={i % 2 ? 14 : -4} r={15} fill={hc} {...st} />
          ))}
          <path d={cap} fill={hc} {...st} />
        </g>
      );
    case 'bun':
      return (
        <g>
          <circle cx={0} cy={-52} r={16} fill={hc} {...st} />
          <path d={cap} fill={hc} {...st} />
        </g>
      );
    case 'elder':
      return (
        <g>
          <circle cx={0} cy={-50} r={13} fill="#f0f0f0" {...st} />
          <path d={cap} fill="#efefef" {...st} />
        </g>
      );
    case 'short':
      return <path d={cap} fill={hc} {...st} />;
    default:
      return null;
  }
};

const Face: React.FC<{mood: Mood; speaking: boolean; f: number}> = ({mood, speaking, f}) => {
  const blink = f % 150 < 5;
  const eyeRy = blink ? 1 : 6;
  const eyes =
    mood === 'senang' ? (
      <g fill="none" stroke={INK} strokeWidth={3.5} strokeLinecap="round">
        <path d="M-20 6 Q-14 -2 -8 6" />
        <path d="M8 6 Q14 -2 20 6" />
      </g>
    ) : mood === 'kaget' ? (
      <g>
        <ellipse cx={-14} cy={4} rx={8} ry={9} fill="#fff" stroke={INK} strokeWidth={2.5} />
        <ellipse cx={14} cy={4} rx={8} ry={9} fill="#fff" stroke={INK} strokeWidth={2.5} />
        <circle cx={-14} cy={5} r={3.5} fill={INK} />
        <circle cx={14} cy={5} r={3.5} fill={INK} />
      </g>
    ) : (
      <g fill={INK}>
        <ellipse cx={-14} cy={4} rx={4.6} ry={eyeRy} />
        <ellipse cx={14} cy={4} rx={4.6} ry={eyeRy} />
      </g>
    );
  const brows: Record<Mood, [string, string]> = {
    senang: ['M-22 -8 Q-14 -13 -8 -8', 'M8 -8 Q14 -13 22 -8'],
    sedih: ['M-22 -4 L-8 -12', 'M8 -12 L22 -4'],
    khawatir: ['M-22 -5 L-8 -12', 'M8 -12 L22 -5'],
    kaget: ['M-22 -17 L-8 -17', 'M8 -17 L22 -17'],
    serius: ['M-22 -10 L-8 -10', 'M8 -10 L22 -10'],
    tekad: ['M-22 -13 L-8 -7', 'M8 -7 L22 -13'],
  };
  const mouths: Record<Mood, string> = {
    senang: 'M-10 18 Q0 29 10 18',
    sedih: 'M-8 25 Q0 16 8 25',
    khawatir: 'M-8 23 Q-3 18 0 23 Q3 28 8 23',
    kaget: 'M0 0',
    serius: 'M-7 23 L7 23',
    tekad: 'M-8 21 Q0 27 8 21',
  };
  const open = speaking ? 3 + 4.5 * Math.abs(Math.sin(f * 0.7)) : 0;
  return (
    <g>
      <circle cx={-24} cy={16} r={6} fill="#ff8f8f" opacity={0.35} />
      <circle cx={24} cy={16} r={6} fill="#ff8f8f" opacity={0.35} />
      {eyes}
      <g fill="none" stroke={INK} strokeWidth={3.5} strokeLinecap="round">
        <path d={brows[mood][0]} />
        <path d={brows[mood][1]} />
      </g>
      {speaking ? (
        <ellipse cx={0} cy={22} rx={6.5} ry={open} fill="#7a2f3a" stroke={INK} strokeWidth={2.5} />
      ) : mood === 'kaget' ? (
        <ellipse cx={0} cy={23} rx={5} ry={7} fill="#7a2f3a" stroke={INK} strokeWidth={2.5} />
      ) : (
        <path d={mouths[mood]} fill="none" stroke={INK} strokeWidth={3.5} strokeLinecap="round" />
      )}
      {mood === 'khawatir' || mood === 'sedih' ? (
        <path d="M38 -16 Q44 -6 38 -2 Q32 -6 38 -16 Z" fill="#9fd4ff" stroke={INK} strokeWidth={2} />
      ) : null}
    </g>
  );
};

export const Person: React.FC<PersonProps> = ({
  spec,
  x,
  y,
  scale = 1,
  flip = false,
  mood = 'serius',
  pose = 'idle',
  item = 'none',
  speaking = false,
  walk = false,
  opacity = 1,
  glow,
  label,
  sub,
  labelColor = C.teal,
}) => {
  const f = useCurrentFrame();
  const phase = x * 0.37;
  const bob = walk ? Math.abs(Math.sin((f + phase) * 0.28)) * 5 : Math.sin((f + phase) / 26) * 1.8;
  const swing = walk ? Math.sin((f + phase) * 0.28) * 20 : 0;
  const base = POSES[pose];
  let r: V = [base.r[0], base.r[1]];
  const l: V = [base.l[0], base.l[1]];
  if (speaking && (pose === 'talk' || pose === 'idle')) {
    r = [64 + Math.cos(f * 0.2) * 5, -134 + Math.sin(f * 0.25) * 8];
  }
  if (pose === 'wave') r = [base.r[0] + Math.sin(f * 0.3) * 14, base.r[1]];
  if (walk && pose === 'idle') {
    l[1] = -78 + Math.sin((f + phase) * 0.28) * 10;
    r[1] = -78 - Math.sin((f + phase) * 0.28) * 10;
  }
  const sleeve = spec.coat ? '#ffffff' : spec.top;
  const hand = spec.gloves ?? spec.skin;
  const headScale = spec.bigHead ? 1.22 : 1;
  const hijab = spec.hairStyle === 'hijab';
  const labelW = Math.max((label ? label.length : 0) * 13, (sub ? sub.length : 0) * 7.6) + 34;

  return (
    <g transform={`translate(${x},${y})`} opacity={opacity}>
      {glow ? <ellipse cx={0} cy={4} rx={72 * scale} ry={15 * scale} fill={glow} opacity={0.55} /> : null}
      <ellipse cx={0} cy={2} rx={48 * scale} ry={9 * scale} fill={C.shadow} />
      <g transform={`scale(${(flip ? -1 : 1) * scale},${scale}) translate(0,${-bob})`}>
        {/* kaki */}
        <g transform={`rotate(${-swing} -16 -76)`}>
          <rect x={-28} y={-76} width={24} height={54} rx={8} fill={spec.pants} stroke={INK} strokeWidth={4} />
          <rect x={-31} y={-28} width={30} height={28} rx={8} fill={spec.boots} stroke={INK} strokeWidth={4} />
        </g>
        <g transform={`rotate(${swing} 16 -76)`}>
          <rect x={4} y={-76} width={24} height={54} rx={8} fill={spec.pants} stroke={INK} strokeWidth={4} />
          <rect x={1} y={-28} width={30} height={28} rx={8} fill={spec.boots} stroke={INK} strokeWidth={4} />
        </g>
        {/* lengan belakang (kiri) */}
        <Arm sx={-34} sy={-140} hx={l[0]} hy={l[1]} sleeve={sleeve} hand={hand} />
        {/* badan */}
        <g transform={spec.cane ? 'rotate(3 0 -76)' : undefined}>
          <rect x={-34} y={-154} width={68} height={84} rx={16} fill={spec.top} stroke={INK} strokeWidth={4} />
          {spec.coat ? <rect x={-36} y={-154} width={72} height={112} rx={14} fill="#ffffff" stroke={INK} strokeWidth={4} /> : null}
          {spec.belly ? <ellipse cx={0} cy={-96} rx={36} ry={30} fill={spec.top} stroke={INK} strokeWidth={4} /> : null}
          {spec.vest ? (
            <g>
              <path d="M-34 -146 Q-34 -154 -26 -154 L-10 -154 L-2 -126 L-2 -72 L-28 -72 Q-34 -72 -34 -80 Z" fill={spec.vest} stroke={INK} strokeWidth={4} strokeLinejoin="round" />
              <path d="M34 -146 Q34 -154 26 -154 L10 -154 L2 -126 L2 -72 L28 -72 Q34 -72 34 -80 Z" fill={spec.vest} stroke={INK} strokeWidth={4} strokeLinejoin="round" />
              <rect x={-31} y={-104} width={26} height={7} fill="rgba(255,255,255,0.75)" />
              <rect x={5} y={-104} width={26} height={7} fill="rgba(255,255,255,0.75)" />
              {spec.vestLabel ? (
                <g transform={`translate(-18,-132) scale(${flip ? -1 : 1},1)`}>
                  <circle r={10} fill="#fff" stroke={INK} strokeWidth={2.5} />
                  <text y={4.5} textAnchor="middle" fontSize={11} fontWeight={800} fill={INK} fontFamily={FONT}>
                    {spec.vestLabel}
                  </text>
                </g>
              ) : null}
            </g>
          ) : null}
        </g>
        {/* tas */}
        {item === 'bag' ? <ItemShape item="bag" l={l} r={r} /> : null}
        {/* leher & kepala */}
        <rect x={-9} y={-162} width={18} height={16} fill={spec.skin} stroke={INK} strokeWidth={3} />
        <g transform={`translate(0,-192) scale(${headScale})`}>
          {hijab ? (
            <g>
              <path d="M-44 6 Q-54 50 -40 66 L40 66 Q54 50 44 6 Z" fill={spec.hijab ?? C.rose} stroke={INK} strokeWidth={3.5} strokeLinejoin="round" />
              <ellipse cx={0} cy={-2} rx={46} ry={50} fill={spec.hijab ?? C.rose} stroke={INK} strokeWidth={3.5} />
              <ellipse cx={0} cy={4} rx={32} ry={36} fill={spec.skin} stroke={INK} strokeWidth={3} />
              <path d="M-33 -6 Q0 -46 33 -6 Q30 -30 0 -36 Q-30 -30 -33 -6 Z" fill={spec.hijab ?? C.rose} stroke={INK} strokeWidth={3} />
            </g>
          ) : (
            <g>
              {spec.hairStyle === 'bob' || spec.hairStyle === 'curly' || spec.hairStyle === 'braid' || spec.hairStyle === 'ponytail' ? (
                <path d="M-44 -8 Q-46 -50 0 -50 Q46 -50 44 -8 L44 24 L-44 24 Z" fill={spec.hair} stroke={INK} strokeWidth={3.5} strokeLinejoin="round" opacity={spec.hairStyle === 'bob' ? 1 : 0} />
              ) : null}
              <circle cx={0} cy={0} r={38} fill={spec.skin} stroke={INK} strokeWidth={4} />
              <Hair spec={spec} />
            </g>
          )}
          <Face mood={mood} speaking={speaking} f={f} />
          {spec.glasses ? (
            <g fill="none" stroke={INK} strokeWidth={3}>
              <circle cx={-15} cy={4} r={12} fill="rgba(255,255,255,0.35)" />
              <circle cx={15} cy={4} r={12} fill="rgba(255,255,255,0.35)" />
              <path d="M-3 4 H3" />
            </g>
          ) : null}
          {spec.mask ? (
            <path d="M-22 28 Q0 48 22 28 L18 44 Q0 54 -18 44 Z" fill="#fff" stroke={INK} strokeWidth={3} />
          ) : null}
          {spec.hat ? (
            <g>
              <path d="M-40 -14 Q0 -66 40 -14 Z" fill={spec.hat} stroke={INK} strokeWidth={3.5} strokeLinejoin="round" />
              <ellipse cx={0} cy={-14} rx={54} ry={9} fill={spec.hat} stroke={INK} strokeWidth={3.5} />
            </g>
          ) : null}
          {spec.peci ? (
            <path d="M-30 -16 Q-30 -50 0 -50 Q30 -50 30 -16 L26 -10 L-26 -10 Z" fill="#1d1c25" stroke={INK} strokeWidth={3} />
          ) : null}
        </g>
        {/* lengan depan (kanan) + item */}
        <Arm sx={34} sy={-140} hx={r[0]} hy={r[1]} sleeve={sleeve} hand={hand} />
        {item !== 'none' && item !== 'bag' ? <ItemShape item={item} l={l} r={r} /> : null}
        {spec.cane ? (
          <g>
            <path d={`M${l[0] - 4} ${l[1]} L${l[0] - 8} 0`} stroke={INK} strokeWidth={9} strokeLinecap="round" />
            <path d={`M${l[0] - 4} ${l[1]} L${l[0] - 8} 0`} stroke={C.woodLight} strokeWidth={4.5} strokeLinecap="round" />
          </g>
        ) : null}
      </g>
      {label ? (
        <g transform={`translate(0,${-(spec.bigHead ? 190 : 258) * scale - 8})`}>
          <rect x={-labelW / 2} y={sub ? -28 : -20} width={labelW} height={sub ? 56 : 40} rx={20} fill={labelColor} stroke={INK} strokeWidth={3} />
          <text textAnchor="middle" y={sub ? -5 : 7} fontSize={20} fontWeight={800} fill="#fff" fontFamily={FONT}>
            {label}
          </text>
          {sub ? (
            <text textAnchor="middle" y={16} fontSize={13} fontWeight={600} fill="#fff" fontFamily={FONT}>
              {sub}
            </text>
          ) : null}
        </g>
      ) : null}
    </g>
  );
};
