import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, FONT, W} from '../assets/theme';
import {SkyBackground} from './Sky';
import {River, Swamp} from './Water';
import {BalaiWarga, Jembatan, StiltHouse, Sumur} from './Buildings';

const WALLS = ['#c98b55', '#b9835a', '#d8a45f', '#a8774a', '#c98b55'];
const ROOFS = ['#2f7a73', '#a8452f', '#5a7a9a', '#2f7a73', '#8a5a3a'];

/** Latar permukiman lahan basah (dunia selebar worldW). Air banjir digambar terpisah (FloodWater). */
export const ExteriorBackdrop: React.FC<{
  weather: number;
  worldW?: number;
  crowd?: number;
  wellFlag?: number;
}> = ({weather, worldW = 2600, crowd = 0, wellFlag = 0}) => {
  const trees = Array.from({length: Math.ceil(worldW / 80)});
  return (
    <g>
      <SkyBackground w={worldW} weather={weather} />
      {trees.map((_, i) => (
        <g key={i}>
          <circle cx={i * 80 + 20} cy={506 + ((i * 13) % 16)} r={46 + ((i * 7) % 16)} fill="#4d7d57" />
          <circle cx={i * 80 + 52} cy={522 + ((i * 11) % 12)} r={38} fill="#3f7550" />
        </g>
      ))}
      <River x={0} y={540} w={1500} h={80} />
      <Swamp x={1500} y={520} w={worldW - 1500} h={150} />
      <Jembatan x={560} y={578} w={480} />
      <rect x={0} y={620} width={worldW} height={500} fill={C.land} />
      <rect x={0} y={690} width={worldW} height={110} fill="#93b26a" opacity={0.7} />
      {[180, 470, 780, 1090, 1400].map((hx, i) => (
        <StiltHouse key={`b${i}`} x={hx} y={725} w={250} scale={0.75} wall={WALLS[i % 5]} roof={ROOFS[(i + 2) % 5]} />
      ))}
      <StiltHouse x={330} y={815} wall={WALLS[0]} roof={ROOFS[0]} />
      <StiltHouse x={900} y={815} wall={WALLS[2]} roof={ROOFS[1]} />
      <StiltHouse x={1330} y={815} wall={WALLS[3]} roof={ROOFS[2]} />
      <StiltHouse x={620} y={862} w={220} stilt={40} wall={WALLS[1]} roof={ROOFS[3]} flip />
      <StiltHouse x={1115} y={862} w={200} stilt={40} wall={WALLS[4]} roof={ROOFS[4]} />
      <Sumur x={480} y={850} flagged={wellFlag} />
      {worldW > 1800 ? <BalaiWarga x={1950} y={815} crowd={crowd} /> : null}
    </g>
  );
};

/** Interior posko di balai warga (ukuran layar 1920x1080). */
export const InteriorBackdrop: React.FC<{weather?: number; banner?: string}> = ({weather = 0.8, banner = 'POSKO KESEHATAN · BALAI WARGA'}) => {
  const f = useCurrentFrame();
  return (
    <g>
      <rect x={0} y={0} width={W} height={760} fill="#dcc196" />
      {Array.from({length: 40}).map((_, i) => (
        <rect key={i} x={i * 48} y={0} width={48} height={760} fill={i % 2 ? 'rgba(120,80,40,0.06)' : 'rgba(255,255,255,0.05)'} />
      ))}
      <rect x={0} y={560} width={W} height={200} fill="#b9895a" />
      <rect x={0} y={556} width={W} height={10} fill={C.woodDark} />
      {[90, 600, 1110, 1620].map((wx) => (
        <g key={wx}>
          <rect x={wx} y={360} width={240} height={250} fill="#b8d6e8" stroke={C.ink} strokeWidth={6} />
          <rect x={wx} y={360} width={240} height={110} fill={weather > 0.5 ? '#8c9aa8' : '#9fcdea'} />
          <rect x={wx} y={520} width={240} height={90} fill={C.flood} opacity={0.9} />
          <circle cx={wx + 50} cy={480} r={30} fill="#4d7d57" />
          <circle cx={wx + 130} cy={486} r={36} fill="#3f7550" />
          {Array.from({length: 6}).map((_, i) => {
            const rx = wx + ((i * 47 + f * 6) % 240);
            const ry = 370 + ((i * 53 + f * 14) % 120);
            return <line key={i} x1={rx} y1={ry} x2={rx - 5} y2={ry + 16} stroke="rgba(255,255,255,0.6)" strokeWidth={2} />;
          })}
          <path d={`M${wx + 120} 360 V610 M${wx} 485 H${wx + 240}`} stroke={C.ink} strokeWidth={6} />
          <rect x={wx - 10} y={606} width={260} height={14} fill={C.woodDark} stroke={C.ink} strokeWidth={4} />
        </g>
      ))}
      <rect x={0} y={760} width={W} height={320} fill="#a8703f" />
      {Array.from({length: 7}).map((_, i) => (
        <path key={i} d={`M0 ${790 + i * 46} H${W}`} stroke="rgba(60,35,15,0.35)" strokeWidth={3} />
      ))}
      <rect x={160} y={800} width={1600} height={230} rx={14} fill="#d8b66a" opacity={0.75} />
      {Array.from({length: 30}).map((_, i) => (
        <path key={i} d={`M${160 + i * 54} 800 V1030`} stroke="rgba(120,80,30,0.25)" strokeWidth={3} />
      ))}
      <path d={`M${W / 2 - 300} 0 V30 M${W / 2 + 300} 0 V30`} stroke={C.ink} strokeWidth={4} />
      <rect x={W / 2 - 330} y={28} width={660} height={54} rx={8} fill={C.teal} stroke={C.ink} strokeWidth={4} />
      <text x={W / 2} y={64} textAnchor="middle" fontSize={26} fontWeight={800} fontFamily={FONT} fill="#fff">
        {banner}
      </text>
    </g>
  );
};
