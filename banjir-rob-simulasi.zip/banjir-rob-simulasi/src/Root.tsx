import React from 'react';
import {CalculateMetadataFunction, Composition, staticFile} from 'remotion';
import {Main} from './Main';
import {AudioManifest, MainProps, Timing} from './lib/timing';
import timingData from '../public/timing.json';
import manifestData from '../public/audio-manifest.json';

const defaultTiming = timingData as unknown as Timing;
const defaultManifest = manifestData as unknown as AudioManifest;

const fetchJson = async <T,>(path: string, fallback: T): Promise<T> => {
  try {
    const res = await fetch(staticFile(path));
    if (!res.ok) return fallback;
    return (await res.json()) as T;
  } catch {
    return fallback;
  }
};

// timing.json & audio-manifest.json dibaca ulang saat render/Studio,
// sehingga timing dapat diedit tanpa mengubah komponen React.
const calculateMetadata: CalculateMetadataFunction<MainProps> = async ({props}) => {
  const timing = await fetchJson<Timing>('timing.json', props.timing);
  const manifest = await fetchJson<AudioManifest>('audio-manifest.json', props.manifest);
  return {durationInFrames: timing.totalFrames, props: {timing, manifest}};
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="BanjirRob"
    component={Main}
    width={1920}
    height={1080}
    fps={30}
    durationInFrames={defaultTiming.totalFrames}
    defaultProps={{timing: defaultTiming, manifest: defaultManifest}}
    calculateMetadata={calculateMetadata}
  />
);
