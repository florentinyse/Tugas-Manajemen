// Palet & konstanta visual. Diubah di sini = berubah di seluruh video.
export const W = 1920;
export const H = 1080;
export const OUTLINE = 4;
export const FONT = '"Segoe UI", "Helvetica Neue", Roboto, Arial, sans-serif';
export const SHADOW = '8px 8px 0 rgba(34,32,43,0.22)';

export const C = {
  ink: '#22202b',
  cream: '#f4ead3',
  paper: '#fbf6ea',
  white: '#ffffff',
  wood: '#a9693b',
  woodDark: '#7a4a2a',
  woodLight: '#c98b55',
  teal: '#2f7a73',
  tealDark: '#1f5550',
  green: '#4f9a62',
  greenDark: '#3f7a4b',
  land: '#9fbd73',
  blue: '#7db4d6',
  blueDeep: '#2f6f96',
  flood: '#8b6b45',
  floodDark: '#6e5233',
  floodLight: '#a98456',
  mustard: '#e3ab3c',
  orange: '#e8793b',
  red: '#d1493f',
  rose: '#c0476a',
  violet: '#7b4fa3',
  skinA: '#f0c29b',
  skinB: '#d9a273',
  skinC: '#b97e52',
  gray: '#6c7380',
  grayLight: '#cfd5db',
  shadow: 'rgba(30,25,40,0.22)',
} as const;
