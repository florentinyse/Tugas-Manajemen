import React, {useMemo} from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {FONT} from './assets/theme';
import {AudioTracks} from './components/AudioTracks';
import {Hud} from './components/Hud';
import {SubtitleLayer} from './components/Subtitle';
import {SCENES} from './scenes';
import {MainProps, SceneProvider} from './lib/timing';

export const Main: React.FC<MainProps> = ({timing, manifest}) => {
  const subtitles = useMemo(() => timing.scenes.flatMap((s) => s.subtitles), [timing]);
  return (
    <AbsoluteFill style={{backgroundColor: '#000', fontFamily: FONT}}>
      {timing.scenes.map((scene) => {
        const Comp = SCENES[scene.sceneKey];
        return (
          <Sequence key={scene.id} from={scene.startFrame} durationInFrames={scene.durationFrames} name={`${scene.number}. ${scene.title}`}>
            <SceneProvider scene={scene}>
              {Comp ? <Comp /> : <AbsoluteFill style={{background: '#400', color: '#fff', fontSize: 48, padding: 60}}>sceneKey "{scene.sceneKey}" tidak terdaftar di src/scenes/index.ts</AbsoluteFill>}
              <Hud />
            </SceneProvider>
          </Sequence>
        );
      })}
      <SubtitleLayer subtitles={subtitles} />
      <AudioTracks timing={timing} manifest={manifest} />
    </AbsoluteFill>
  );
};
