import React, {createContext, useContext} from 'react';
import {useCurrentFrame} from 'remotion';
import {clamp01} from './anim';

export type Line = {
  id: string;
  speaker: string;
  startFrame: number;
  endFrame: number;
  text: string;
};

export type Subtitle = {
  id: string;
  speaker: string;
  startFrame: number;
  endFrame: number;
  text: string;
};

export type SceneTiming = {
  id: string;
  number: number;
  title: string;
  sceneKey: string;
  startFrame: number;
  endFrame: number;
  durationFrames: number;
  hourStart: number;
  hourEnd: number;
  narration: string;
  lines: Line[];
  subtitles: Subtitle[];
};

export type Timing = {
  fps: number;
  width: number;
  height: number;
  title: string;
  totalFrames: number;
  tailFrames: number;
  scenes: SceneTiming[];
};

export type AudioManifest = {
  narration: Record<string, string>;
};

export type MainProps = {
  timing: Timing;
  manifest: AudioManifest;
};

const SceneCtx = createContext<SceneTiming | null>(null);

export const SceneProvider: React.FC<{scene: SceneTiming; children: React.ReactNode}> = ({
  scene,
  children,
}) => <SceneCtx.Provider value={scene}>{children}</SceneCtx.Provider>;

export const useScene = (): SceneTiming => {
  const s = useContext(SceneCtx);
  if (!s) {
    throw new Error('useScene harus dipakai di dalam <SceneProvider>.');
  }
  return s;
};

export type Cue = {
  f: number;
  scene: SceneTiming;
  /** progres adegan 0..1 */
  p: number;
  /** pembicara aktif saat ini (atau null) */
  speaker: string | null;
  /** posisi (0..1) awal kalimat ke-idx di dalam adegan */
  mark: (idx: number) => number;
  /** 0..1: animasi masuk yang dipicu saat kalimat ke-idx mulai diucapkan */
  appear: (idx: number, dur?: number, delay?: number) => number;
  /** 0..1: terlihat dari kalimat `from` sampai sebelum kalimat `to` */
  visible: (from: number, to?: number, dur?: number) => number;
  /** apakah kalimat ke-idx sedang diucapkan */
  active: (idx: number) => boolean;
};

/**
 * Semua animasi yang berkaitan dengan naskah dipicu lewat hook ini, sehingga
 * visual otomatis mengikuti perubahan di public/timing.json.
 */
export const useCue = (): Cue => {
  const f = useCurrentFrame();
  const scene = useScene();
  const abs = f + scene.startFrame;
  const startOf = (idx: number): number => {
    const l = scene.lines[Math.min(Math.max(idx, 0), scene.lines.length - 1)];
    return l ? l.startFrame - scene.startFrame : 0;
  };
  const appear = (idx: number, dur = 16, delay = 0): number =>
    idx < 0 || idx >= scene.lines.length ? 1 : clamp01((f - startOf(idx) - delay) / dur);
  const speakerLine = scene.lines.find((l) => abs >= l.startFrame && abs < l.endFrame);
  return {
    f,
    scene,
    p: Math.min(1, f / Math.max(1, scene.durationFrames - 1)),
    speaker: speakerLine ? speakerLine.speaker : null,
    mark: (idx) => startOf(idx) / Math.max(1, scene.durationFrames),
    appear,
    visible: (from, to, dur = 14) => {
      const a = appear(from, dur);
      const b = to === undefined ? 0 : appear(to, 12);
      return a * (1 - b);
    },
    active: (idx) => {
      const l = scene.lines[idx];
      return !!l && abs >= l.startFrame && abs < l.endFrame;
    },
  };
};

export const useSpeaker = (): string | null => {
  const f = useCurrentFrame();
  const scene = useScene();
  const abs = f + scene.startFrame;
  const l = scene.lines.find((x) => abs >= x.startFrame && abs < x.endFrame);
  return l ? l.speaker : null;
};
