import {Easing} from 'remotion';

export const clamp01 = (n: number): number => Math.max(0, Math.min(1, n));

const inOut = Easing.inOut(Easing.cubic);
const out = Easing.out(Easing.cubic);

export const ease = (t: number): number => inOut(clamp01(t));
export const easeOut = (t: number): number => out(clamp01(t));

/** Progres 0..1 antara p=a dan p=b dengan easing. */
export const seg = (p: number, a: number, b: number): number =>
  b === a ? (p >= b ? 1 : 0) : ease((p - a) / (b - a));

/** Muncul dengan sedikit "membal". */
export const popScale = (t: number): number => {
  const c = clamp01(t);
  return easeOut(c) * (1 + 0.1 * Math.sin(c * Math.PI));
};

export const wave = (f: number, period: number, amp = 1, phase = 0): number =>
  Math.sin(((f + phase) / period) * Math.PI * 2) * amp;
