import type {Item, Mood, PersonSpec} from '../components/Person';
import {C} from '../assets/theme';

// Desain 4 tokoh utama. Warna rambut, rompi, hijab, dll. bisa diubah di sini
// (mis. ganti hairStyle 'hijab' -> 'bob' agar sesuai penampilan anggota kelompok).
export type TeamName = 'Nayla' | 'Natasha' | 'Syifa' | 'Kayla';

export type TeamMember = {
  name: TeamName;
  role: string;
  short: string;
  accent: string;
  item: Item;
  mood: Mood;
  spec: PersonSpec;
};

export const TEAM_ORDER: TeamName[] = ['Nayla', 'Natasha', 'Syifa', 'Kayla'];

export const TEAM: Record<TeamName, TeamMember> = {
  Nayla: {
    name: 'Nayla',
    role: 'Koordinator Respons',
    short: 'Koordinator',
    accent: C.orange,
    item: 'radio',
    mood: 'tekad',
    spec: {skin: '#e8b88f', hair: '#2a1f2d', hairStyle: 'ponytail', top: '#f4ead3', vest: C.orange, vestLabel: 'N', pants: '#3a4a63', boots: '#2f3a4a'},
  },
  Natasha: {
    name: 'Natasha',
    role: 'Surveilans & Penilaian Situasi',
    short: 'Surveilans & RNA',
    accent: C.blueDeep,
    item: 'clipboard',
    mood: 'serius',
    spec: {skin: '#f0c29b', hair: '#5a3a2a', hairStyle: 'bob', glasses: true, mask: true, top: '#ffffff', vest: C.blueDeep, vestLabel: 'T', pants: '#4b5563', boots: '#2f3a4a'},
  },
  Syifa: {
    name: 'Syifa',
    role: 'Sanitasi, Higiene & Lingkungan',
    short: 'Sanitasi & Higiene',
    accent: C.green,
    item: 'soap',
    mood: 'senang',
    spec: {skin: '#d9a273', hair: '#3b2a20', hairStyle: 'braid', hat: '#e0c46a', gloves: C.mustard, top: '#f1f5e9', vest: C.green, vestLabel: 'S', pants: '#b89a62', boots: '#e3ab3c'},
  },
  Kayla: {
    name: 'Kayla',
    role: 'Logistik, Komunikasi Risiko & Pemantauan Warga',
    short: 'Logistik & Risiko',
    accent: C.violet,
    item: 'bag',
    mood: 'senang',
    spec: {skin: '#e3b08a', hair: '#2a1f2d', hairStyle: 'hijab', hijab: C.rose, top: '#fff3f0', vest: C.violet, vestLabel: 'K', pants: '#4b4f60', boots: '#5a3a2a'},
  },
};

export type ResidentKind =
  | 'bapak'
  | 'ibu'
  | 'lansiaPria'
  | 'lansiaWanita'
  | 'bumil'
  | 'anakL'
  | 'anakP'
  | 'kader'
  | 'relawan'
  | 'kades'
  | 'nakes';

export type ResidentPreset = {spec: PersonSpec; scale: number; mood: Mood};

export const RESIDENTS: Record<ResidentKind, ResidentPreset> = {
  bapak: {scale: 1, mood: 'khawatir', spec: {skin: C.skinB, hair: '#2a2420', hairStyle: 'short', top: '#c85a4a', pants: '#4a5568', boots: '#6b4a2f'}},
  ibu: {scale: 0.96, mood: 'khawatir', spec: {skin: C.skinA, hair: '#2a2420', hairStyle: 'hijab', hijab: '#6aa0a8', top: '#e9c46a', pants: '#7a5a8a', boots: '#6b4a2f'}},
  lansiaPria: {scale: 0.95, mood: 'sedih', spec: {skin: C.skinC, hair: '#e6e6e6', hairStyle: 'elder', cane: true, top: '#9aa5b1', pants: '#59606b', boots: '#4a3a2a'}},
  lansiaWanita: {scale: 0.92, mood: 'khawatir', spec: {skin: C.skinB, hair: '#bbb', hairStyle: 'hijab', hijab: '#b8b8c4', cane: true, top: '#8d9a86', pants: '#59606b', boots: '#4a3a2a'}},
  bumil: {scale: 0.98, mood: 'khawatir', spec: {skin: C.skinA, hair: '#3b2a20', hairStyle: 'bun', belly: true, top: '#f2a7b5', pants: '#6b6f86', boots: '#6b4a2f'}},
  anakL: {scale: 0.62, mood: 'kaget', spec: {skin: C.skinB, hair: '#2a2420', hairStyle: 'short', bigHead: true, top: '#4aa3df', pants: '#e9c46a', boots: '#c85a4a'}},
  anakP: {scale: 0.6, mood: 'senang', spec: {skin: C.skinA, hair: '#3b2a20', hairStyle: 'braid', bigHead: true, top: '#f08fb0', pants: '#7a8cc0', boots: '#e3ab3c'}},
  kader: {scale: 0.96, mood: 'serius', spec: {skin: C.skinB, hair: '#2a2420', hairStyle: 'hijab', hijab: '#e8d8b8', top: '#ffffff', vest: '#1f8a8a', vestLabel: 'KD', pants: '#4b5563', boots: '#2f3a4a'}},
  relawan: {scale: 1, mood: 'tekad', spec: {skin: C.skinA, hair: '#2a2420', hairStyle: 'short', top: '#e9edf2', vest: C.red, vestLabel: 'R', pants: '#3a4a63', boots: '#2f3a4a'}},
  kades: {scale: 1, mood: 'serius', spec: {skin: C.skinB, hair: '#2a2420', hairStyle: 'short', peci: true, top: '#8a5a2b', pants: '#33323c', boots: '#222'}},
  nakes: {scale: 0.98, mood: 'serius', spec: {skin: C.skinA, hair: '#2a2420', hairStyle: 'bun', coat: true, mask: true, top: '#ffffff', pants: '#3a6ea5', boots: '#2f3a4a'}},
};
