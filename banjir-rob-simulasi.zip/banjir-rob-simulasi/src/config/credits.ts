// Teks identitas pada kartu judul & penutup. Ubah sesuai kelompok/kampus.
export const CREDITS = {
  title: 'SIMULASI RESPONS KESEHATAN MASYARAKAT DALAM 72 JAM PERTAMA BANJIR ROB DAN RISIKO PENYAKIT BERBASIS LINGKUNGAN',
  scenario: 'Skenario 5 — Banjir Rob dan Penyakit Berbasis Lingkungan',
  course: 'Manajemen Bencana di Lingkungan Lahan Basah dan KLB',
  team: 'Nayla · Natasha · Syifa · Kayla',
  // Tambahkan baris lain bila perlu (nama kelompok, kampus, dosen, dll.)
  extra: [] as string[],
  disclaimer: 'Seluruh angka bersumber dari skenario tugas. Target indikator adalah target simulasi, bukan hasil kejadian nyata.',
  closing: 'Di lahan basah, kesehatan dijaga bersama warga.',
};
