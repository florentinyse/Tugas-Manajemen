// Konfigurasi audio. Semua volume 0..1. Narasi selalu lebih keras daripada musik/ambience.
export const AUDIO = {
  narrationVolume: 1.0,
  music: {enabled: true, file: 'audio/music-bed.wav', volume: 0.1, fadeInSec: 1.5, fadeOutSec: 3},
  files: {
    rain: 'audio/rain.wav',
    water: 'audio/water.wav',
    murmur: 'audio/murmur.wav',
    pop: 'audio/pop.wav',
    swoosh: 'audio/swoosh.wav',
  },
  // Ambience per sceneKey (dikalikan volume dasar di bawah).
  ambience: {
    pembuka: {rain: 0.9, water: 0.6, murmur: 0.3},
    identifikasi: {rain: 0.35, water: 0.15, murmur: 0.2},
    respons24: {rain: 0.3, water: 0.1, murmur: 0.3},
    respons48: {rain: 0.45, water: 0.5, murmur: 0.35},
    perkembangan: {rain: 0.25, water: 0.15, murmur: 0.2},
    respons72: {rain: 0.1, water: 0.1, murmur: 0.25},
    indikator: {rain: 0, water: 0, murmur: 0},
    risiko: {rain: 0, water: 0, murmur: 0},
    penutup: {rain: 0, water: 0.2, murmur: 0.3},
  } as Record<string, {rain: number; water: number; murmur: number}>,
  baseVolume: {rain: 0.1, water: 0.08, murmur: 0.07},
  sfx: {
    enabled: true,
    swooshOnSceneStart: true,
    swooshVolume: 0.14,
    popVolume: 0.12,
    // adegan yang memunculkan panel infografis -> bunyi "pop" lembut di awal tiap kalimat
    popOnLinesFor: ['identifikasi', 'respons24', 'perkembangan', 'respons72', 'indikator', 'risiko'],
  },
};
