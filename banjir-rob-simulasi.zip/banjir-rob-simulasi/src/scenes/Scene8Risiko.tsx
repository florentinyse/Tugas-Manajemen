import React from 'react';
import {C, FONT, OUTLINE, SHADOW} from '../assets/theme';
import {InteriorBackdrop} from '../components/Backdrops';
import {Character} from '../components/Characters';
import {Icon, IconName} from '../components/Icons';
import {SceneShell, Stage} from '../components/SceneShell';
import {clamp01} from '../lib/anim';
import {useCue} from '../lib/timing';

type Risk = {no: number; title: string; icon: IconName; color: string; mit: {icon: IconName; text: string}[]};
const RISKS: Risk[] = [
  {
    no: 1,
    title: 'Wilayah sulit dijangkau (genangan & akses terbatas)',
    icon: 'route',
    color: C.red,
    mit: [
      {icon: 'people', text: 'Memanfaatkan kader lokal untuk pemantauan'},
      {icon: 'pin', text: 'Menggunakan pemetaan wilayah terdampak'},
      {icon: 'route', text: 'Menentukan prioritas akses'},
      {icon: 'box', text: 'Mengatur distribusi logistik bertahap'},
      {icon: 'link', text: 'Koordinasi dengan relawan & pemerintah setempat'},
    ],
  },
  {
    no: 2,
    title: 'Air minum aman & logistik kesehatan terbatas',
    icon: 'bottle',
    color: C.orange,
    mit: [
      {icon: 'chart', text: 'Menentukan prioritas distribusi sesuai kebutuhan'},
      {icon: 'box', text: 'Mengidentifikasi sumber logistik tambahan'},
      {icon: 'link', text: 'Koordinasi lintas sektor'},
      {icon: 'eye', text: 'Memantau stok & kebutuhan berkala'},
      {icon: 'droplet', text: 'Edukasi pengolahan & penggunaan air aman'},
    ],
  },
];

const RiskCard: React.FC<{r: Risk; x: number; t: number; k: number}> = ({r, x, t, k}) => (
  <div style={{position: 'absolute', left: x, top: 112, width: 830, height: 640, opacity: t, transform: `translateY(${(1 - t) * 40}px)`, background: C.paper, border: `${OUTLINE}px solid ${C.ink}`, borderRadius: 26, boxShadow: SHADOW, overflow: 'hidden', fontFamily: FONT, color: C.ink}}>
    <div style={{height: 110, background: r.color, display: 'flex', alignItems: 'center', gap: 18, padding: '0 26px', borderBottom: `${OUTLINE}px solid ${C.ink}`}}>
      <Icon name={r.icon} size={64} bg="#fff" color={r.color} />
      <div style={{color: '#fff'}}>
        <div style={{fontSize: 22, fontWeight: 800, letterSpacing: 1}}>RISIKO {r.no}</div>
        <div style={{fontSize: 29, fontWeight: 800, lineHeight: 1.12}}>{r.title}</div>
      </div>
    </div>
    <div style={{padding: '14px 28px'}}>
      <div style={{fontSize: 22, fontWeight: 800, color: C.green, marginBottom: 10, letterSpacing: 1}}>MITIGASI</div>
      <div style={{display: 'flex', flexDirection: 'column', gap: 12}}>
        {r.mit.map((m, i) => {
          const tt = clamp01(k * (r.mit.length + 1) - i);
          return (
            <div key={m.text} style={{display: 'flex', alignItems: 'center', gap: 16, opacity: tt, transform: `translateX(${(1 - tt) * 40}px)`}}>
              <div style={{width: 56, height: 56, borderRadius: '50%', background: '#e6eef3', border: `3px solid ${C.ink}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0}}>
                <Icon name={m.icon} size={36} />
              </div>
              <div style={{fontSize: 27, fontWeight: 700, lineHeight: 1.15}}>{m.text}</div>
            </div>
          );
        })}
      </div>
    </div>
  </div>
);

export const Scene8Risiko: React.FC = () => {
  const cue = useCue();
  return (
    <SceneShell>
      <Stage>
        <InteriorBackdrop weather={0.3} banner="RISIKO PELAKSANAAN & MITIGASI" />
        <Character who="Nayla" x={330} y={925} scale={0.82} />
        <Character who="Natasha" x={640} y={925} scale={0.82} />
        <Character who="Syifa" x={1280} y={925} scale={0.82} />
        <Character who="Kayla" x={1590} y={925} scale={0.82} />
      </Stage>
      <RiskCard r={RISKS[0]} x={70} t={cue.appear(1, 20)} k={cue.appear(1, 100, 10)} />
      <RiskCard r={RISKS[1]} x={1020} t={cue.appear(2, 20)} k={cue.appear(2, 100, 10)} />
    </SceneShell>
  );
};
