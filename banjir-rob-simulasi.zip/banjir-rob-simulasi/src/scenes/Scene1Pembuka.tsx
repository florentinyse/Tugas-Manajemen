import React from 'react';
import {C, FONT} from '../assets/theme';
import {CREDITS} from '../config/credits';
import {CameraRig} from '../components/CameraRig';
import {Character, Resident} from '../components/Characters';
import {ExteriorBackdrop} from '../components/Backdrops';
import {Jukung, Titian} from '../components/Buildings';
import {SceneShell} from '../components/SceneShell';
import {FloodWater} from '../components/Water';
import {Chip} from '../components/Infographic';
import {ease, seg} from '../lib/anim';
import {useCue} from '../lib/timing';
import {TEAM_ORDER} from '../config/characters';

const TitleCard: React.FC = () => {
  const cue = useCue();
  const t = 1 - ease((cue.f - 96) / 18);
  if (t <= 0.01) return null;
  return (
    <div style={{position: 'absolute', inset: 0, background: 'rgba(14,24,38,0.88)', opacity: t, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', fontFamily: FONT, color: '#fff', textAlign: 'center', padding: '0 180px'}}>
      <div style={{fontSize: 30, fontWeight: 700, color: C.mustard, letterSpacing: 2, marginBottom: 26}}>{CREDITS.scenario.toUpperCase()}</div>
      <div style={{fontSize: 58, fontWeight: 800, lineHeight: 1.22}}>{CREDITS.title}</div>
      <div style={{fontSize: 30, fontWeight: 600, marginTop: 36, opacity: 0.9}}>{CREDITS.course}</div>
      <div style={{fontSize: 28, fontWeight: 600, marginTop: 10, color: '#9fd4ff'}}>{CREDITS.team}</div>
      {CREDITS.extra.map((e) => (
        <div key={e} style={{fontSize: 26, marginTop: 6, opacity: 0.85}}>{e}</div>
      ))}
      <div style={{position: 'absolute', bottom: 54, fontSize: 22, opacity: 0.75}}>{CREDITS.disclaimer}</div>
    </div>
  );
};

const Badge: React.FC<{t: number; big: string; small: string; color: string}> = ({t, big, small, color}) => (
  <div style={{padding: '10px 26px', background: color, border: `4px solid ${C.ink}`, borderRadius: 22, boxShadow: '6px 6px 0 rgba(34,32,43,0.25)', color: '#fff', fontFamily: FONT, textAlign: 'center', opacity: t, transform: `scale(${0.8 + 0.2 * t})`}}>
    <div style={{fontSize: 46, fontWeight: 800, lineHeight: 1.05}}>{big}</div>
    <div style={{fontSize: 22, fontWeight: 600}}>{small}</div>
  </div>
);

export const Scene1Pembuka: React.FC = () => {
  const cue = useCue();
  const f = cue.f;
  const waterTop = 860 - 72 * seg(cue.p, 0.08, 0.7);
  const intro = cue.appear(4, 40);
  const walkX = (a: number, b: number) => a + ((b - a) * cue.p);
  const boatX = 1180 + 520 * seg(cue.p, 0.3, 0.85);
  return (
    <SceneShell rain={0.9}>
      <CameraRig
        worldW={2600}
        keys={[
          {at: 0, cx: 760, cy: 560, s: 1.0},
          {line: 2, cx: 1150, cy: 570, s: 1.05},
          {line: 3, cx: 1850, cy: 590, s: 1.1},
          {line: 4, cx: 1830, cy: 600, s: 1.22},
        ]}
      >
        <ExteriorBackdrop weather={1} crowd={cue.visible(3) > 0 ? 9 : 4} />
        <Resident kind="bapak" x={walkX(420, 760)} y={868} pose="carry" item="box" walk mood="khawatir" />
        <Resident kind="ibu" x={walkX(980, 1210)} y={872} pose="carry" item="box" walk flip mood="kaget" />
        <Resident kind="lansiaPria" x={1290} y={866} mood="sedih" flip />
        <Resident kind="anakL" x={1350} y={870} mood="kaget" flip />
        <FloodWater width={2600} top={waterTop} debris />
        <Jukung x={boatX} y={waterTop + 34} scale={0.9}>
          <Resident kind="ibu" x={-40} y={-30} scale={0.8} mood="khawatir" />
          <Resident kind="anakP" x={30} y={-30} mood="khawatir" />
        </Jukung>
        <Titian x={1380} y={905} w={1200} />
        {TEAM_ORDER.map((n, i) => (
          <Character key={n} who={n} x={1680 + i * 150 - (1 - ease(intro)) * 260} y={905} scale={0.95} walk={intro < 0.98} opacity={intro} />
        ))}
      </CameraRig>
      <div style={{position: 'absolute', top: 110, left: 0, right: 0, display: 'flex', justifyContent: 'center', gap: 28}}>
        <Badge t={cue.visible(2, 3)} big="± 900" small="penduduk terdampak" color={C.red} />
        <Badge t={cue.visible(2, 3)} big="120 · 65 · 18" small="anak-anak · lansia · ibu hamil" color={C.orange} />
        <Badge t={cue.visible(3, 4)} big="± 200" small="orang di balai warga" color={C.teal} />
      </div>
      <div style={{position: 'absolute', top: 262, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 22}}>
        <Chip icon="rain" text="Pasang tinggi + hujan" t={cue.visible(0, 1)} />
        <Chip icon="clock" text="Tergenang > 24 jam" t={cue.visible(1, 2)} />
        <Chip icon="home" text="Sebagian mengungsi ke rumah kerabat" t={cue.visible(3, 4)} color="#fff3cf" />
      </div>
      <TitleCard />
    </SceneShell>
  );
};
