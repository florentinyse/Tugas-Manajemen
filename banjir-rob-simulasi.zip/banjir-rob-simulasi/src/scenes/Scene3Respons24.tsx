import React from 'react';
import {C, FONT} from '../assets/theme';
import {Briefing, CoordDiagram} from '../components/Briefing';
import {Icon} from '../components/Icons';
import {FlowPanel, IconRow, ListPanel, PanelShell, SettlementMap} from '../components/Infographic';
import {TEAM, TEAM_ORDER} from '../config/characters';
import {useCue} from '../lib/timing';

const TASKS: Record<string, string> = {
  Nayla: 'Koordinasi & penyesuaian strategi',
  Natasha: 'RNA, surveilans, pencatatan & pelaporan',
  Syifa: 'Air bersih, sanitasi, higiene & genangan',
  Kayla: 'Logistik, komunikasi risiko & kader',
};

export const Scene3Respons24: React.FC = () => {
  const cue = useCue();
  const v = (i: number) => cue.visible(i, i === 5 ? undefined : i + 1);
  return (
    <Briefing phase="0–24 JAM" sub="Koordinasi · RNA · Surveilans awal · Air aman" icon="clock" color={C.teal}>
      <PanelShell t={v(0)} title="KOORDINASI AWAL" icon="link" color={C.orange}>
        <CoordDiagram k={cue.appear(0, 60)} f={cue.f} />
      </PanelShell>
      <ListPanel
        t={v(1)}
        k={cue.appear(1, 90)}
        title="RAPID NEEDS ASSESSMENT (RNA)"
        icon="clipboard"
        color={C.blueDeep}
        rows={[
          {icon: 'pin', text: 'Lokasi terdampak', color: '#f6d9a8'},
          {icon: 'home', text: 'Lokasi pengungsian', sub: 'balai warga & rumah kerabat', color: '#f6d9a8'},
          {icon: 'people', text: 'Kelompok rentan', sub: 'anak-anak, lansia, ibu hamil', color: '#fbd9b8'},
          {icon: 'box', text: 'Kebutuhan dasar', sub: 'air minum, sanitasi, logistik', color: '#cfe3f3'},
        ]}
        footer="Penilaian cepat kebutuhan kesehatan"
      />
      <PanelShell t={v(2)} title="SURVEILANS AWAL & PEMETAAN" icon="eye" color={C.blueDeep}>
        <div style={{display: 'flex', gap: 24}}>
          <div style={{display: 'flex', flexDirection: 'column', gap: 20, width: 330, marginTop: 8}}>
            <IconRow item={{icon: 'cross', text: 'Diare', color: '#f5c2c0'}} t={cue.appear(2, 14)} fontSize={28} />
            <IconRow item={{icon: 'skin', text: 'Keluhan kulit', color: '#f5c2c0'}} t={cue.appear(2, 14, 10)} fontSize={28} />
            <IconRow item={{icon: 'clipboard', text: 'Dicatat di formulir surveilans', color: '#e6eef3'}} t={cue.appear(2, 14, 20)} fontSize={24} />
          </div>
          <div style={{marginTop: 28}}>
            <SettlementMap width={460} reveal={{unreached: cue.appear(2, 24, 20), sumur: 1, septic: 1}} />
          </div>
        </div>
      </PanelShell>
      <PanelShell t={v(3)} title="PENGAMANAN AIR MINUM" icon="droplet" color={C.green}>
        <div style={{display: 'flex', flexDirection: 'column', gap: 26, marginTop: 6}}>
          <IconRow item={{icon: 'well', text: 'Sumur tercemar diberi tanda', sub: 'DILARANG DIMINUM', color: '#f5c2c0'}} t={cue.appear(3, 14)} />
          <IconRow item={{icon: 'bottle', text: 'Distribusi air minum aman & air bersih', color: '#cfe3f3'}} t={cue.appear(3, 14, 14)} />
          <IconRow item={{icon: 'people', text: 'Edukasi: jangan konsumsi air sumur tercemar', color: '#d7e8c4'}} t={cue.appear(3, 14, 28)} />
          <div style={{display: 'flex', alignItems: 'center', gap: 20, marginTop: 6, justifyContent: 'center', opacity: cue.appear(3, 20, 40)}}>
            <Icon name="well" size={96} />
            <span style={{fontSize: 56, fontWeight: 800, color: C.red}}>✕</span>
            <span style={{fontSize: 40, color: C.ink}}>→</span>
            <Icon name="bottle" size={96} color={C.blue} />
            <span style={{fontSize: 56, fontWeight: 800, color: C.green}}>✓</span>
          </div>
        </div>
      </PanelShell>
      <FlowPanel
        t={v(4)}
        k={cue.appear(4, 80)}
        title="LOGISTIK & PRIORITAS RENTAN"
        icon="box"
        color={C.violet}
        steps={[
          {icon: 'box', label: 'Air minum & logistik'},
          {icon: 'home', label: 'Balai warga'},
          {icon: 'people', label: 'Kelompok rentan dahulu', sub: 'ibu hamil · anak · lansia'},
        ]}
        note="Prioritas: ibu hamil (18), anak (120), lansia (65)"
      />
      <PanelShell t={v(5)} title="PEMBAGIAN TUGAS" icon="link" color={C.orange}>
        <div style={{display: 'flex', flexDirection: 'column', gap: 20}}>
          {TEAM_ORDER.map((n, i) => {
            const t = cue.appear(5, 14, i * 10);
            return (
              <div key={n} style={{display: 'flex', alignItems: 'center', gap: 20, opacity: t, transform: `translateX(${(1 - t) * 40}px)`}}>
                <div style={{width: 70, height: 70, borderRadius: '50%', background: TEAM[n].accent, border: `4px solid ${C.ink}`, color: '#fff', fontSize: 34, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FONT}}>
                  {n[0]}
                </div>
                <div>
                  <div style={{fontSize: 32, fontWeight: 800}}>{n} <span style={{fontSize: 22, color: C.gray, fontWeight: 600}}>· {TEAM[n].short}</span></div>
                  <div style={{fontSize: 26, fontWeight: 600}}>{TASKS[n]}</div>
                </div>
              </div>
            );
          })}
          <div style={{marginTop: 10, padding: '12px 20px', background: '#fff3cf', border: `3px solid ${C.ink}`, borderRadius: 16, fontSize: 26, fontWeight: 700, opacity: cue.appear(5, 20, 50)}}>
            Satu jalur koordinasi: laporan → Nayla → desa & Puskesmas
          </div>
        </div>
      </PanelShell>
    </Briefing>
  );
};
