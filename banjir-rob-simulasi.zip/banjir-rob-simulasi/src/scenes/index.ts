import React from 'react';
import {Scene1Pembuka} from './Scene1Pembuka';
import {Scene2Identifikasi} from './Scene2Identifikasi';
import {Scene3Respons24} from './Scene3Respons24';
import {Scene4Respons48} from './Scene4Respons48';
import {Scene5Perkembangan} from './Scene5Perkembangan';
import {Scene6Respons72} from './Scene6Respons72';
import {Scene7Indikator} from './Scene7Indikator';
import {Scene8Risiko} from './Scene8Risiko';
import {Scene9Penutup} from './Scene9Penutup';

// Kunci = "sceneKey" di public/timing.json
export const SCENES: Record<string, React.FC> = {
  pembuka: Scene1Pembuka,
  identifikasi: Scene2Identifikasi,
  respons24: Scene3Respons24,
  respons48: Scene4Respons48,
  perkembangan: Scene5Perkembangan,
  respons72: Scene6Respons72,
  indikator: Scene7Indikator,
  penutup: Scene9Penutup,
  risiko: Scene8Risiko,
};
