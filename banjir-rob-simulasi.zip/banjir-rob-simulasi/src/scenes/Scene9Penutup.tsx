import React from 'react';
import {C, FONT, OUTLINE, SHADOW} from '../assets/theme';
import {ExteriorBackdrop} from '../components/Backdrops';
import {Titian} from '../components/Buildings';
import {CameraRig} from '../components/CameraRig';
import {Character, Resident} from '../components/Characters';
import {Icon, IconName} from '../components/Icons';
import {SceneShell} from '../components/SceneShell';
import {FloodWater} from '../components/Water';
import {CREDITS} from '../config/credits';
import {clamp01} from '../lib/anim';
import {useCue} from '../lib/timing';

const ITEMS: {icon: IconName; text: string; color: string; line: number; order: number}[] = [
  {icon: 'link', text: 'Koordinasi lintas sektor', color: C.orange, line: 0, order: 0},
  {icon: 'eye', text: 'Surveilans & penilaian cepat', color: C.blueDeep, line: 0, order: 1},
  {icon: 'droplet', text: 'Air, sanitasi & higiene', color: C.green, line: 0, order: 2},
  {icon: 'shield', text: 'Perlindungan kelompok rentan', color: C.violet, line: 0, order: 3},
  {icon: 'mosquito', text: 'Pengendalian risiko penyakit berbasis lingkungan', color: C.teal, line: 1, order: 0},
  {icon: 'chart', text: 'Pemantauan & penyesuaian respons', color: C.red, line: 1, order: 1},
];

export const Scene9Penutup: React.FC = () => {
  const cue = useCue();
  const closing = cue.appear(2, 30);
  const top = 840 + 20 * cue.p;
  return (
    <SceneShell>
      <CameraRig
        worldW={2600}
        keys={[
          {at: 0, cx: 1850, cy: 580, s: 1.1},
          {at: 1, cx: 1700, cy: 560, s: 1.0},
        ]}
      >
        <ExteriorBackdrop weather={0.1} crowd={10} />
        <FloodWater width={2600} top={top - 50} debris />
        <Titian x={1380} y={905} w={1200} />
        <Resident kind="lansiaWanita" x={1470} y={905} mood="senang" />
        <Resident kind="anakP" x={1540} y={905} mood="senang" pose="wave" />
        <Character who="Syifa" x={1640} y={905} scale={0.95} mood="senang" />
        <Character who="Natasha" x={1790} y={905} scale={0.95} mood="senang" />
        <Character who="Nayla" x={1940} y={905} scale={0.95} mood="senang" pose={cue.speaker === 'Nayla' ? 'talk' : 'wave'} />
        <Character who="Kayla" x={2090} y={905} scale={0.95} mood="senang" />
        <Resident kind="kader" x={2220} y={905} mood="senang" flip />
        <Resident kind="bumil" x={2320} y={905} mood="senang" flip />
        <Resident kind="anakL" x={2390} y={905} mood="senang" pose="wave" flip />
      </CameraRig>
      <div style={{position: 'absolute', top: 108, left: 60, right: 60, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18, fontFamily: FONT}}>
        {ITEMS.map((it) => {
          const t = clamp01(cue.appear(it.line, 16, it.order * 22));
          return (
            <div key={it.text} style={{height: 92, display: 'flex', alignItems: 'center', gap: 14, padding: '0 20px 0 12px', background: it.color, border: `${OUTLINE}px solid ${C.ink}`, borderRadius: 24, boxShadow: SHADOW, color: '#fff', fontSize: 26, fontWeight: 800, lineHeight: 1.1, opacity: t, transform: `translateY(${(1 - t) * -20}px)`}}>
              <Icon name={it.icon} size={60} bg="#fff" color={it.color} />
              {it.text}
            </div>
          );
        })}
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 360, display: 'flex', justifyContent: 'center', opacity: closing, transform: `scale(${0.9 + 0.1 * closing})`, fontFamily: FONT}}>
        <div style={{padding: '20px 54px', background: 'rgba(255,255,255,0.94)', border: `${OUTLINE}px solid ${C.ink}`, borderRadius: 30, boxShadow: SHADOW, fontSize: 56, fontWeight: 800, color: C.tealDark, textAlign: 'center'}}>
          {CREDITS.closing}
        </div>
      </div>
    </SceneShell>
  );
};
