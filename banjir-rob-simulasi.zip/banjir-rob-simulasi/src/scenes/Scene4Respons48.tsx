import React from 'react';
import {IconName} from '../components/Icons';
import {ExteriorBackdrop} from '../components/Backdrops';
import {BoxStack, DeskTable, HandwashStation, Latrine, StiltHouse, Titian, WaterCrate} from '../components/Buildings';
import {CameraRig} from '../components/CameraRig';
import {Character, Resident} from '../components/Characters';
import {Chip} from '../components/Infographic';
import {SceneShell} from '../components/SceneShell';
import {FloodWater} from '../components/Water';
import {useCue} from '../lib/timing';

type ChipDef = {icon: IconName; text: string};
// kalimat ke-i -> chip yang tampil (selaras dengan urutan kalimat di timing.json)
const CHIPS: ChipDef[][] = [
  [{icon: 'clock', text: 'Respons 24–48 jam: pantau & cegah'}],
  [{icon: 'clipboard', text: 'Pemantauan & pencatatan kasus harian'}],
  [{icon: 'soap', text: 'Cuci tangan pakai sabun'}, {icon: 'droplet', text: 'Air minum aman & air bersih'}, {icon: 'toilet', text: 'Sanitasi darurat & limbah'}],
  [{icon: 'mosquito', text: 'Pengelolaan genangan yang aman (vektor)'}],
  [{icon: 'radio', text: 'Komunikasi risiko & edukasi'}, {icon: 'box', text: 'Distribusi kebutuhan kesehatan & logistik'}],
  [{icon: 'eye', text: 'Kader memantau warga di rumah'}, {icon: 'shield', text: 'Pemantauan kelompok rentan'}],
  [{icon: 'droplet', text: 'Jangan pakai air sumur tercemar'}],
  [{icon: 'droplet', text: 'Pakai air minum aman yang dibagikan'}],
  [{icon: 'chart', text: 'Satu laporan harian & evaluasi'}],
];

export const Scene4Respons48: React.FC = () => {
  const cue = useCue();
  const top = 790;
  const last = CHIPS.length - 1;
  return (
    <SceneShell rain={0.45}>
      <CameraRig
        worldW={2600}
        keys={[
          {at: 0, cx: 1300, cy: 570, s: 0.98},
          {line: 1, cx: 1840, cy: 610, s: 1.15},
          {line: 2, cx: 1380, cy: 610, s: 1.15},
          {line: 4, cx: 900, cy: 610, s: 1.12},
          {line: 6, cx: 1400, cy: 610, s: 1.15},
          {line: 8, cx: 1300, cy: 580, s: 0.98},
        ]}
      >
        <ExteriorBackdrop weather={0.7} crowd={9} wellFlag={1} />
        <Resident kind="lansiaPria" x={822} y={703} scale={0.8} mood="sedih" pose="idle" />
        <FloodWater width={2600} top={top} debris />
        <Titian x={560} y={905} w={1940} />
        {/* Stasiun C: logistik & kader */}
        <BoxStack x={640} y={905} n={3} />
        <WaterCrate x={700} y={905} />
        <Resident kind="relawan" x={590} y={905} scale={0.95} pose="carry" item="box" mood="tekad" flip />
        <Character who="Kayla" x={780} y={905} scale={0.95} pose={cue.speaker === 'Kayla' ? 'talk' : 'idle'} />
        <Resident kind="kader" x={880} y={905} scale={0.95} pose="point" mood="serius" flip />
        {/* Nayla memantau */}
        <Character who="Nayla" x={1130 + Math.sin(cue.f / 80) * 10} y={905} scale={0.95} />
        {/* Stasiun B: sanitasi & higiene */}
        <Latrine x={1240} y={905} />
        <Character who="Syifa" x={1420} y={905} scale={0.95} />
        <HandwashStation x={1520} y={905} />
        <Resident kind="anakL" x={1590} y={905} mood="senang" pose="wave" />
        <Resident kind="ibu" x={1700} y={905} speakerName="Warga" mood="khawatir" flip />
        {/* Stasiun A: pencatatan */}
        <DeskTable x={1890} y={905} />
        <Character who="Natasha" x={1830} y={905} scale={0.95} />
        <Resident kind="bumil" x={1990} y={905} mood="khawatir" flip />
        <Resident kind="bapak" x={2090} y={905} mood="sedih" flip />
        <StiltHouse x={2380} y={862} w={200} stilt={40} wall="#a8774a" roof="#2f7a73" />
      </CameraRig>
      <div style={{position: 'absolute', top: 112, left: 0, right: 0, height: 140}}>
        {CHIPS.map((set, i) => {
          const t = cue.visible(i, i < last ? i + 1 : undefined);
          if (t <= 0.01) return null;
          return (
            <div key={i} style={{position: 'absolute', left: 0, right: 0, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 14, padding: '0 120px'}}>
              {set.map((c) => (
                <Chip key={c.text} icon={c.icon} text={c.text} t={t} />
              ))}
            </div>
          );
        })}
      </div>
    </SceneShell>
  );
};
