import React from 'react';
import {C, FONT} from '../assets/theme';
import {Briefing} from '../components/Briefing';
import {Resident} from '../components/Characters';
import {Icon} from '../components/Icons';
import {FlowPanel, ListPanel, PanelShell, SettlementMap, TilesPanel} from '../components/Infographic';
import {useCue} from '../lib/timing';

export const Scene5Perkembangan: React.FC = () => {
  const cue = useCue();
  const v = (i: number) => cue.visible(i, i === 5 ? undefined : i + 1);
  return (
    <Briefing phase="HARI KE-2" sub="Perkembangan situasi → respons disesuaikan" icon="warn" color={C.red}>
      <TilesPanel
        t={v(0)}
        k={cue.appear(0, 70)}
        title="PERKEMBANGAN SITUASI"
        icon="warn"
        color={C.red}
        tiles={[
          {icon: 'droplet', big: 'Genangan', label: 'belum berkurang signifikan', color: '#8b6b45'},
          {icon: 'thermo', big: 'Demam', label: 'beberapa warga mulai mengalami demam', color: '#c4574d'},
        ]}
        note="Strategi respons perlu disesuaikan"
      />
      <PanelShell t={v(1)} title="LAPORAN KADER" icon="radio" color="#1f8a8a">
        <div style={{display: 'flex', gap: 24, alignItems: 'center'}}>
          <svg width={260} height={380} viewBox="0 0 260 380" style={{flexShrink: 0}}>
            <Resident kind="kader" x={130} y={350} scale={1.35} pose="talk" item="phone" speakerName="Kader" mood="khawatir" />
          </svg>
          <div style={{flex: 1}}>
            <div style={{position: 'relative', padding: '22px 26px', background: '#fff', border: `4px solid ${C.ink}`, borderRadius: 24, fontSize: 32, fontWeight: 700, lineHeight: 1.3, fontFamily: FONT}}>
              “Ada beberapa warga demam di wilayah yang belum terjangkau.”
            </div>
            <div style={{display: 'flex', gap: 18, marginTop: 28, alignItems: 'center', opacity: cue.appear(1, 20, 20)}}>
              <Icon name="thermo" size={72} />
              <Icon name="thermo" size={72} />
              <Icon name="pin" size={72} color={C.red} />
              <span style={{fontSize: 26, fontWeight: 700}}>lokasi dicatat untuk ditindaklanjuti</span>
            </div>
          </div>
        </div>
      </PanelShell>
      <FlowPanel
        t={v(2)}
        k={cue.appear(2, 80)}
        title="PENILAIAN ULANG SITUASI"
        icon="eye"
        color={C.orange}
        steps={[
          {icon: 'thermo', label: 'Demam', sub: 'gejala'},
          {icon: 'eye', label: 'Dinilai lebih lanjut'},
          {icon: 'clipboard', label: 'Pemeriksaan'},
          {icon: 'hospital', label: 'Rujukan', sub: 'sesuai kebutuhan'},
        ]}
        note="Penyebab demam belum disimpulkan — dinilai berdasarkan gejala & pemeriksaan"
      />
      <ListPanel
        t={v(3)}
        k={cue.appear(3, 80)}
        title="SURVEILANS DIPERKUAT"
        icon="clipboard"
        color={C.blueDeep}
        rows={[
          {icon: 'thermo', text: 'Pantau kasus demam & keluhan lain', color: '#f5c2c0'},
          {icon: 'clipboard', text: 'Data warga yang perlu pemeriksaan', color: '#e6eef3'},
          {icon: 'hospital', text: 'Koordinasi & rujukan ke Puskesmas', color: '#f5c2c0'},
        ]}
        footer="Rujukan sesuai indikasi"
      />
      <ListPanel
        t={v(4)}
        k={cue.appear(4, 80)}
        title="PENYESUAIAN PRIORITAS"
        icon="box"
        color={C.violet}
        rows={[
          {icon: 'box', text: 'Prioritas distribusi logistik disesuaikan', color: '#e0d2f0'},
          {icon: 'people', text: 'Kader memperkuat pemantauan', sub: 'wilayah yang belum terjangkau', color: '#d7e8c4'},
          {icon: 'pin', text: 'Pemetaan diperbarui', color: '#cfe3f3'},
        ]}
      />
      <PanelShell t={v(5)} title="TINJAU ULANG RISIKO LINGKUNGAN" icon="mosquito" color={C.green} titleSize={30}>
        <div style={{display: 'flex', justifyContent: 'center', marginTop: 6}}>
          <SettlementMap width={800} reveal={{sumur: 1, septic: 1, nyamuk: cue.appear(5, 24), unreached: 1, fever: cue.appear(5, 24, 20), rentan: 1}} />
        </div>
      </PanelShell>
    </Briefing>
  );
};
