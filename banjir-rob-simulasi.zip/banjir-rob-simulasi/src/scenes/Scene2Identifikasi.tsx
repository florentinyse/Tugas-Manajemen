import React from 'react';
import {C} from '../assets/theme';
import {InteriorBackdrop} from '../components/Backdrops';
import {TeamRow} from '../components/Characters';
import {IconRow, PanelShell, RowItem, SettlementMap} from '../components/Infographic';
import {SceneShell, Stage} from '../components/SceneShell';
import {useCue} from '../lib/timing';

const ROWS: {item: RowItem; line: number; order: number}[] = [
  {item: {icon: 'droplet', text: 'Septic tank & saluran terendam', color: '#f6d9a8'}, line: 1, order: 0},
  {item: {icon: 'well', text: 'Air sumur berubah warna & berbau', color: '#f6d9a8'}, line: 1, order: 1},
  {item: {icon: 'cross', text: 'Risiko diare & penyakit berbasis lingkungan', color: '#f5c2c0'}, line: 2, order: 0},
  {item: {icon: 'skin', text: 'Keluhan kulit akibat air banjir', color: '#f5c2c0'}, line: 2, order: 1},
  {item: {icon: 'mosquito', text: 'Genangan: potensi sarang nyamuk', color: '#d7e8c4'}, line: 2, order: 2},
  {item: {icon: 'bottle', text: 'Air minum kemasan hanya ± 1 hari', color: '#cfe3f3'}, line: 3, order: 0},
  {item: {icon: 'pin', text: 'Wilayah belum terjangkau pemantauan', color: '#cfe3f3'}, line: 3, order: 1},
  {item: {icon: 'people', text: 'Rentan: anak (120), lansia (65), ibu hamil (18)', color: '#fbd9b8'}, line: 4, order: 0},
];

export const Scene2Identifikasi: React.FC = () => {
  const cue = useCue();
  return (
    <SceneShell>
      <Stage>
        <InteriorBackdrop weather={0.8} />
        <TeamRow xs={[320, 640, 1280, 1600]} y={905} scale={0.85} poses={{Nayla: cue.speaker === 'Nayla' ? 'point' : 'idle'}} moods={{Nayla: 'tekad'}} />
      </Stage>
      <PanelShell t={cue.appear(0, 18)} title="PETA SITUASI (SIMULASI)" icon="pin" color={C.teal} x={60} y={120} w={940} h={590} titleSize={30}>
        <div style={{display: 'flex', justifyContent: 'center', marginTop: -6}}>
          <SettlementMap
            width={800}
            reveal={{balai: cue.appear(0, 18), sumur: cue.appear(1, 20), septic: cue.appear(1, 20, 10), nyamuk: cue.appear(2, 20), unreached: cue.appear(3, 20), rentan: cue.appear(4, 20)}}
          />
        </div>
      </PanelShell>
      <PanelShell t={cue.appear(0, 18)} title="MASALAH PRIORITAS" icon="warn" color={C.red} x={1040} y={120} w={820} h={590} titleSize={30}>
        <div style={{display: 'flex', flexDirection: 'column', gap: 11, marginTop: -8}}>
          {ROWS.map((r) => (
            <IconRow key={r.item.text} item={r.item} t={cue.appear(r.line, 14, r.order * 8)} size={34} fontSize={25} />
          ))}
        </div>
      </PanelShell>
    </SceneShell>
  );
};
