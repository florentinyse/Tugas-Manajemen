import React from 'react';
import {C, FONT, OUTLINE, SHADOW} from '../assets/theme';
import {Character} from '../components/Characters';
import {Icon, IconName} from '../components/Icons';
import {SceneShell, Stage} from '../components/SceneShell';
import {InteriorBackdrop} from '../components/Backdrops';
import {CREDITS} from '../config/credits';
import {useCue} from '../lib/timing';

type Ind = {no: number; title: string; icon: IconName; color: string; def: string; ukur: string; target: string};
const INDS: Ind[] = [
  {
    no: 1,
    title: 'Surveilans Kesehatan',
    icon: 'eye',
    color: C.blueDeep,
    def: 'Persentase warga terdampak atau warga di lokasi pengungsian yang telah terdata dan dipantau kondisi kesehatannya dalam 72 jam pertama.',
    ukur: 'Warga terdata & dipantau ÷ perkiraan warga terdampak × 100% (rekap formulir RNA & kader).',
    target: '≥ 90%',
  },
  {
    no: 2,
    title: 'Air Minum Aman',
    icon: 'droplet',
    color: C.green,
    def: 'Persentase lokasi pengungsian atau rumah tangga prioritas yang memperoleh akses air minum aman sesuai kebutuhan selama periode respons.',
    ukur: 'Lokasi/rumah tangga prioritas terlayani ÷ seluruh lokasi/rumah tangga prioritas × 100% (catatan distribusi).',
    target: '≥ 90%',
  },
  {
    no: 3,
    title: 'Respons Penyakit',
    icon: 'cross',
    color: C.red,
    def: 'Persentase laporan warga dengan gejala diare, keluhan kulit, atau demam yang telah ditindaklanjuti melalui penilaian kesehatan atau rujukan sesuai indikasi.',
    ukur: 'Laporan gejala ditindaklanjuti ÷ seluruh laporan gejala × 100% (buku surveilans & catatan rujukan).',
    target: '≥ 95%',
  },
];

const Label: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div style={{fontSize: 18, fontWeight: 800, letterSpacing: 1, color: C.gray, marginBottom: 2}}>{children}</div>
);

const Card: React.FC<{ind: Ind; t: number; x: number}> = ({ind, t, x}) => (
  <div
    style={{
      position: 'absolute',
      left: x,
      top: 112,
      width: 560,
      height: 600,
      opacity: t,
      transform: `translateY(${(1 - t) * 40}px)`,
      background: C.paper,
      border: `${OUTLINE}px solid ${C.ink}`,
      borderRadius: 26,
      boxShadow: SHADOW,
      overflow: 'hidden',
      fontFamily: FONT,
      color: C.ink,
    }}
  >
    <div style={{height: 82, background: ind.color, display: 'flex', alignItems: 'center', gap: 14, padding: '0 24px', borderBottom: `${OUTLINE}px solid ${C.ink}`}}>
      <Icon name={ind.icon} size={50} bg="#fff" color={ind.color} />
      <div style={{fontSize: 30, fontWeight: 800, color: '#fff'}}>Indikator {ind.no}: {ind.title}</div>
    </div>
    <div style={{padding: '14px 24px'}}>
      <Label>DEFINISI</Label>
      <div style={{fontSize: 22, fontWeight: 600, lineHeight: 1.25, minHeight: 138}}>{ind.def}</div>
      <div style={{height: 10}} />
      <Label>CARA PENGUKURAN</Label>
      <div style={{fontSize: 21, fontWeight: 600, lineHeight: 1.25, minHeight: 106}}>{ind.ukur}</div>
      <div style={{display: 'flex', alignItems: 'center', gap: 20, marginTop: 8}}>
        <svg width={104} height={104} viewBox="0 0 104 104">
          <circle cx={52} cy={52} r={44} fill="#fff" stroke={ind.color} strokeWidth={10} strokeDasharray="14 10" />
          <text x={52} y={61} textAnchor="middle" fontSize={26} fontWeight={800} fill={C.ink} fontFamily={FONT}>{ind.target}</text>
        </svg>
        <div>
          <div style={{fontSize: 24, fontWeight: 800}}>TARGET SIMULASI</div>
          <div style={{fontSize: 19, fontWeight: 600, color: C.gray}}>bukan hasil kejadian nyata</div>
        </div>
      </div>
    </div>
  </div>
);

export const Scene7Indikator: React.FC = () => {
  const cue = useCue();
  const xs = [90, 680, 1270];
  return (
    <SceneShell>
      <Stage>
        <InteriorBackdrop weather={0.3} banner="INDIKATOR PEMANTAUAN" />
        <Character who="Natasha" x={370} y={915} scale={0.85} />
        <Character who="Syifa" x={960} y={915} scale={0.85} />
        <Character who="Kayla" x={1550} y={915} scale={0.85} />
        <Character who="Nayla" x={1850} y={915} scale={0.8} pose="point" flip />
      </Stage>
      {INDS.map((ind, i) => (
        <Card key={ind.no} ind={ind} x={xs[i]} t={cue.appear(i + 1, 20)} />
      ))}
      <div style={{position: 'absolute', left: 0, right: 0, top: 724, display: 'flex', justifyContent: 'center', opacity: cue.appear(0, 20), fontFamily: FONT}}>
        <div style={{padding: '6px 26px', background: '#fff3cf', border: `3px solid ${C.ink}`, borderRadius: 30, fontSize: 22, fontWeight: 700, color: C.ink}}>
          {CREDITS.disclaimer}
        </div>
      </div>
    </SceneShell>
  );
};
