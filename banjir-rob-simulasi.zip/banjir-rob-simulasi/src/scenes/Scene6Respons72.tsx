import React from 'react';
import {C} from '../assets/theme';
import {Briefing} from '../components/Briefing';
import {FlowPanel, ListPanel, TilesPanel} from '../components/Infographic';
import {useCue} from '../lib/timing';

export const Scene6Respons72: React.FC = () => {
  const cue = useCue();
  const v = (i: number) => cue.visible(i, i === 4 ? undefined : i + 1);
  return (
    <Briefing phase="48–72 JAM" sub="Penguatan · evaluasi · tindak lanjut" icon="chart" color={C.green}>
      <ListPanel
        t={v(0)}
        k={cue.appear(0, 70)}
        title="EVALUASI 72 JAM PERTAMA"
        icon="clock"
        color={C.green}
        rows={[
          {icon: 'check', text: '0–24 jam: respons awal', sub: 'koordinasi, RNA, surveilans awal', color: '#d7e8c4'},
          {icon: 'check', text: '24–48 jam: pemantauan & penyesuaian', sub: 'higiene, sanitasi, kader', color: '#d7e8c4'},
          {icon: 'clock', text: '48–72 jam: penguatan & evaluasi', sub: 'sedang berjalan', color: '#fff3cf'},
        ]}
      />
      <FlowPanel
        t={v(1)}
        k={cue.appear(1, 80)}
        title="PEMANTAUAN & PELAPORAN"
        icon="eye"
        color={C.blueDeep}
        steps={[
          {icon: 'eye', label: 'Pemantauan berkala'},
          {icon: 'clipboard', label: 'Pencatatan'},
          {icon: 'chart', label: 'Pelaporan surveilans'},
          {icon: 'hospital', label: 'Puskesmas & lintas sektor'},
        ]}
        note="Kasus yang perlu pemeriksaan dirujuk sesuai indikasi"
      />
      <TilesPanel
        t={v(2)}
        k={cue.appear(2, 80)}
        title="AIR, SANITASI & VEKTOR"
        icon="droplet"
        color={C.green}
        tiles={[
          {icon: 'droplet', big: 'Air minum aman', label: 'distribusi dievaluasi', color: '#3a7bb0'},
          {icon: 'toilet', big: 'Sanitasi darurat', label: 'diperkuat', color: '#4f9a62'},
          {icon: 'mosquito', big: 'Genangan & vektor', label: 'sesuai kondisi lapangan', color: '#8b6b45'},
        ]}
      />
      <ListPanel
        t={v(3)}
        k={cue.appear(3, 80)}
        title="LOGISTIK & KELOMPOK RENTAN"
        icon="box"
        color={C.violet}
        rows={[
          {icon: 'box', text: 'Kebutuhan logistik dihitung ulang', color: '#e0d2f0'},
          {icon: 'chart', text: 'Stok & kebutuhan dipantau berkala', color: '#e6eef3'},
          {icon: 'people', text: 'Kelompok rentan tetap dipantau', sub: 'anak, lansia, ibu hamil', color: '#fbd9b8'},
        ]}
      />
      <ListPanel
        t={v(4)}
        k={cue.appear(4, 100)}
        title="TINDAK LANJUT"
        icon="route"
        color={C.orange}
        fontSize={27}
        rows={[
          {icon: 'link', text: 'Koordinasi lintas sektor berlanjut', color: '#fbd9b8'},
          {icon: 'eye', text: 'Surveilans & pelaporan berkelanjutan', color: '#cfe3f3'},
          {icon: 'toilet', text: 'Sanitasi & pemantauan vektor', color: '#d7e8c4'},
          {icon: 'people', text: 'Pemantauan kelompok rentan', color: '#fbd9b8'},
          {icon: 'box', text: 'Evaluasi kebutuhan logistik', color: '#e0d2f0'},
        ]}
      />
    </Briefing>
  );
};
